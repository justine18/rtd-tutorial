#
# GAMS - General Algebraic Modeling System Python API
#
# Copyright (c) 2017-2023 GAMS Development Corp. <support@gams.com>
# Copyright (c) 2017-2023 GAMS Software GmbH <support@gams.com>
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
#

import pandas as pd
from gams.core import gmd
import gams.transfer._abcs as abcs
from gams.transfer.syms import (
    Set,
    Parameter,
    Variable,
    Equation,
    Alias,
    UniverseAlias,
)

from gams.transfer._internals import (
    CasePreservingDict,
    SpecialValues,
    GamsSymbol,
    GamsSymbolTuple,
    DomainStatus,
    TRANSFER_TYPE,
)
import re


def container_read(container, load_from, symbols, records):
    save_spec_values = gmd.doubleArray(gmd.GMS_SVIDX_MAX)
    gmd.gmdGetUserSpecialValues(load_from, save_spec_values)

    # setting special values
    specVals = gmd.doubleArray(gmd.GMS_SVIDX_MAX)
    specVals[gmd.GMS_SVIDX_UNDEF] = SpecialValues.UNDEF
    specVals[gmd.GMS_SVIDX_NA] = SpecialValues.NA
    specVals[gmd.GMS_SVIDX_EPS] = SpecialValues.EPS
    specVals[gmd.GMS_SVIDX_PINF] = SpecialValues.POSINF
    specVals[gmd.GMS_SVIDX_MINF] = SpecialValues.NEGINF

    rc = gmd.gmdSetSpecialValues(load_from, specVals)
    assert rc

    # get number of symbols
    ret = gmd.gmdInfo(load_from, gmd.GMD_NRSYMBOLSWITHALIAS)
    symCount = ret[1]

    # get names of all symbols
    syms = []
    rc = gmd.new_intp()
    for i in range(symCount):
        sym = gmd.gmdGetSymbolByNumberPy(load_from, i, rc)
        ret = gmd.gmdSymbolInfo(load_from, sym, gmd.GMD_NAME)
        syms.append(ret[3])

    if symbols is None:
        read_symbols = syms
    else:
        cf_syms = list(map(str.casefold, syms))
        for i in symbols:
            if i.casefold() not in cf_syms:
                raise ValueError(
                    f"User specified to read symbol `{i}`, "
                    "but it does not exist in the GMD/GamsDatabase Object."
                )

        read_symbols = symbols

    # check if there are any duplicate symbols in the container
    for i in read_symbols:
        if i in container:
            raise Exception(
                f"Attempting to create a new symbol (through a read operation) named `{i}` "
                "but an object with this name already exists in the Container. "
                "Symbol replacement is only possible if the existing symbol is "
                "first removed from the Container with the `<container>.removeSymbols()` method."
            )

    # read meta-information for all gmd symbols
    rc = gmd.new_intp()
    cf_read_symbols = list(map(str.casefold, read_symbols))
    for i in range(symCount):
        sym = gmd.gmdGetSymbolByNumberPy(load_from, i, rc)
        _, _, _, name = gmd.gmdSymbolInfo(load_from, sym, gmd.GMD_NAME)

        if name.casefold() in cf_read_symbols:
            _, userinfo, _, _ = gmd.gmdSymbolInfo(load_from, sym, gmd.GMD_USERINFO)
            _, typ = gmd.gmdSymbolType(load_from, sym)
            _, dim, _, _ = gmd.gmdSymbolInfo(load_from, sym, gmd.GMD_DIM)
            _, _, domains_as_strings = gmd.gmdGetDomain(load_from, sym, dim)
            _, _, _, expltxt = gmd.gmdSymbolInfo(load_from, sym, gmd.GMD_EXPLTEXT)

            sym = gmd.gmdGetSymbolByNumberPy(load_from, userinfo, rc)
            _, _, _, parent_set = gmd.gmdSymbolInfo(load_from, sym, gmd.GMD_NAME)

            # adjustments for aliases (gmd is zero indexed unlike gdx)
            if typ == 4:
                userinfo = userinfo + 1

            # recast as necessary
            typ, userinfo = GamsSymbolTuple((typ, userinfo)).value

            # test for type
            if GamsSymbolTuple((typ, userinfo)) is GamsSymbolTuple.UNKNOWN:
                raise Exception(
                    f"Unknown GDX symbol classification (GAMS Type= {typ}, GAMS Subtype= {userinfo}). ",
                    f"Cannot load symbol `{name}`",
                )

            # create the symbols in the container
            if GamsSymbol[GamsSymbolTuple((typ, userinfo)).name] is GamsSymbol.ALIAS:
                if parent_set in read_symbols:
                    Alias(container, name, container[parent_set])
                else:
                    raise Exception(
                        (
                            f"Cannot create the Alias symbol `{name}` "
                            f"because the parent set (`{parent_set}`) is not "
                            "being read into the in the Container. "
                            "Alias symbols require the parent set object to exist in the Container. "
                            f"Add `{parent_set}` to the list of symbols to read."
                        )
                    )

            elif (
                GamsSymbol[GamsSymbolTuple((typ, userinfo)).name]
                is GamsSymbol.UNIVERSE_ALIAS
            ):
                UniverseAlias(container, name)

            elif GamsSymbol[GamsSymbolTuple((typ, userinfo)).name] is GamsSymbol.SET:
                Set(
                    container,
                    name,
                    domains_as_strings,
                    is_singleton=False,
                    description=expltxt,
                )

            elif (
                GamsSymbol[GamsSymbolTuple((typ, userinfo)).name]
                is GamsSymbol.SINGLETON_SET
            ):
                Set(
                    container,
                    name,
                    domains_as_strings,
                    is_singleton=True,
                    description=expltxt,
                )
            elif (
                GamsSymbol[GamsSymbolTuple((typ, userinfo)).name]
                is GamsSymbol.PARAMETER
            ):
                Parameter(
                    container,
                    name,
                    domains_as_strings,
                    description=expltxt,
                )

            elif (
                GamsSymbol[GamsSymbolTuple((typ, userinfo)).name] in GamsSymbol.VARIABLE
            ):
                Variable(
                    container,
                    name,
                    TRANSFER_TYPE[GamsSymbol[GamsSymbolTuple((typ, userinfo)).name]],
                    domains_as_strings,
                    description=expltxt,
                )

            elif (
                GamsSymbol[GamsSymbolTuple((typ, userinfo)).name] in GamsSymbol.EQUATION
            ):
                Equation(
                    container,
                    name,
                    TRANSFER_TYPE[GamsSymbol[GamsSymbolTuple((typ, userinfo)).name]],
                    domains_as_strings,
                    description=expltxt,
                )

    # main records read
    if records == True:
        # get and store uels
        uels = container._gams2np.gmdGetUelList(load_from)
        uels.remove("INVALID")
        uels.insert(0, "*")

        for symname in read_symbols:
            if not isinstance(container[symname], abcs.ABCAlias):
                # do the read
                df = pd.DataFrame(
                    container._gams2np.gmdReadSymbolStr(load_from, symname, uels)
                )

                # set the records
                if not df.empty:
                    # create categorical
                    for x in range(len(df.columns)):
                        if x < container[symname].dimension:
                            df.isetitem(
                                x,
                                df.iloc[:, x].astype(
                                    pd.CategoricalDtype(
                                        categories=df.iloc[:, x].unique(),
                                        ordered=True,
                                    ),
                                ),
                            )
                        else:
                            if isinstance(container[symname], abcs.ABCSet):
                                df.isetitem(x, df.iloc[:, x].astype(str))
                            else:
                                df.isetitem(x, df.iloc[:, x].astype(float))

                    container[symname].records = df

                    # set column names
                    container[symname].domain_labels = container[symname].domain_names

                else:
                    container[symname].records = None

        # link domain objects and categories
        container._linkDomainObjects(read_symbols)

    # reset GMD special values
    gmd.gmdSetSpecialValues(load_from, save_spec_values)


def container_write(container, write_to, symbols, uel_priority, merge_symbols):
    save_spec_values = gmd.doubleArray(gmd.GMS_SVIDX_MAX)
    gmd.gmdGetUserSpecialValues(write_to, save_spec_values)

    # setting special values
    specVals = gmd.doubleArray(gmd.GMS_SVIDX_MAX)
    specVals[gmd.GMS_SVIDX_UNDEF] = SpecialValues.UNDEF
    specVals[gmd.GMS_SVIDX_NA] = SpecialValues.NA
    specVals[gmd.GMS_SVIDX_EPS] = SpecialValues.EPS
    specVals[gmd.GMS_SVIDX_PINF] = SpecialValues.POSINF
    specVals[gmd.GMS_SVIDX_MINF] = SpecialValues.NEGINF

    rc = gmd.gmdSetSpecialValues(write_to, specVals)
    assert rc

    # get number of symbols
    ret = gmd.gmdInfo(write_to, gmd.GMD_NRSYMBOLSWITHALIAS)
    symCount = ret[1]

    # read in all metadata if merge_symbols is not None
    if merge_symbols is None:
        syms = []
        rc = gmd.new_intp()
        for i in range(symCount):
            sym = gmd.gmdGetSymbolByNumberPy(write_to, i, rc)
            _, _, _, name = gmd.gmdSymbolInfo(write_to, sym, gmd.GMD_NAME)
    else:
        syms = CasePreservingDict()
        rc = gmd.new_intp()
        for i in range(symCount):
            sym = gmd.gmdGetSymbolByNumberPy(write_to, i, rc)
            _, _, _, name = gmd.gmdSymbolInfo(write_to, sym, gmd.GMD_NAME)
            _, userinfo, _, _ = gmd.gmdSymbolInfo(write_to, sym, gmd.GMD_USERINFO)
            _, typ = gmd.gmdSymbolType(write_to, sym)
            _, dim, _, _ = gmd.gmdSymbolInfo(write_to, sym, gmd.GMD_DIM)
            _, domains_as_ptrs, domains_as_strings = gmd.gmdGetDomain(
                write_to, sym, dim
            )
            _, _, _, expltxt = gmd.gmdSymbolInfo(write_to, sym, gmd.GMD_EXPLTEXT)
            _, nrecs, _, _ = gmd.gmdSymbolInfo(write_to, sym, gmd.GMD_NRRECORDS)

            # figure out domain_type
            if all([i == "*" for i in domains_as_strings]):
                domain_type = "none"

            elif any(
                domains_as_ptrs[n] is None for n, i in enumerate(domains_as_strings)
            ):
                domain_type = "relaxed"

            elif all(
                [
                    domains_as_ptrs[n] is not None
                    for n, i in enumerate(domains_as_strings)
                ]
            ):
                domain_type = "regular"

            syms[name] = {}
            syms[name]["dimension"] = dim
            syms[name]["gams_type"] = typ
            syms[name]["gams_subtype"] = userinfo
            syms[name]["domains_as_strings"] = domains_as_strings
            syms[name]["description"] = expltxt
            syms[name]["number_records"] = nrecs
            syms[name]["domain_type"] = domain_type

    # check if partial write is possible
    if symbols is not None:
        if any(i not in syms for i in symbols):
            raise Exception(
                "Writing a subset of symbols from a Container is only enabled for "
                "symbols that currently exist in the GMD/GamsDatabase object"
                "This restriction may be relaxed in a future release."
            )

    else:
        symbols = container.listSymbols(is_valid=True)

    # get symbol objects
    symobjs = container.getSymbols(symbols)
    symnames = [sym.name for sym in symobjs]

    # check symbols
    for symobj in symobjs:
        if not symobj.isValid():
            raise Exception(
                "Cannot write to GMD because symbol `{symbobj.name}` is invalid. "
                "Use `<symbol>.isValid(verbose=True)` to debug."
            )

    # check if domains are valid
    for symname, symobj in zip(symnames, symobjs):
        if symobj.records is not None:
            if symobj.records.iloc[:, : symobj.dimension].isna().sum().sum() != 0:
                raise Exception(
                    f"Categories are missing from the data in symbol `{symname}` -- "
                    "has resulted in `NaN` domains labels. "
                    "Cannot write to GMD until domain labels have been been restored."
                )

    # casefolded arguments
    symbols_cf = list(map(str.casefold, symbols))

    if merge_symbols is not None:
        merge_symbols_cf = list(map(str.casefold, merge_symbols))

    # check if merge is possible
    for i in merge_symbols:
        if i.casefold() not in symbols_cf:
            raise Exception(
                f"User specified merge operation for symbol `{i}`, "
                f"however user did not specify that `{i}` should be written. "
                f"Add `{i}` to the 'symbols' argument."
            )

        if i not in syms:
            raise Exception(
                f"User specified merge operation for symbol `{i}`, "
                "however symbol does not exist in the GMD object"
            )

        if i not in container:
            raise Exception(
                f"User specified merge operation for symbol `{i}`, "
                "however symbol does not exist in the Container"
            )

        # check if symbol types are the same
        if (
            container[i]._gams_type != syms[i]["gams_type"]
            or container[i]._gams_subtype != syms[i]["gams_subtype"]
        ):
            raise Exception(
                f"User specified merge operation for symbol `{i}`. "
                "However, symbol types do not match (GMD symbol type = "
                f"`{_BaseSymbol._type_subtype_lbl[(syms[i]['gams_type'], syms[i]['gams_subtype'])]}` "
                "and Container symbol type = "
                f"`{_BaseSymbol._type_subtype_lbl[(container[i]._gams_type, container[i]._gams_subtype)]}`)"
            )

        if isinstance(container[i], Alias):
            raise Exception(
                f"Alias symbols cannot be merged, remove symbol `{i}` "
                "from the merge_symbols list."
            )

        # check if the dimension is the same
        if container[i].dimension != syms[i]["dimension"]:
            raise Exception(
                f"User specified merge operation for symbol `{i}`. "
                "However, symbol dimensionality does not match (GMD symbol dimension = "
                f"{syms[i]['dimension']} and Container symbol dimension = "
                f"{container[i].dimension})"
            )

    # reorder symbols if necessary
    if container._isValidSymbolOrder() == False:
        container.reorderSymbols()

    #
    # register the universe
    if uel_priority is None:
        [gmd.gmdMergeUel(write_to, i) for i in container.getUELs(symbols)]

    else:
        [gmd.gmdMergeUel(write_to, i) for i in uel_priority]
        [gmd.gmdMergeUel(write_to, i) for i in container.getUELs(symbols)]

    # main write
    for symname, symobj in zip(symnames, symobjs):
        if isinstance(symobj, Alias):
            _, idx, _, _ = gmd.gmdSymbolInfo(
                write_to,
                gmd.gmdFindSymbolPy(write_to, symobj.alias_with.name, rc),
                gmd.GMD_NUMBER,
            )

            ret = gmd.gmdAddSymbolXPy(
                write_to,
                symobj.name,
                symobj.dimension,
                gmd.GMS_DT_ALIAS,
                idx,
                f"Aliased with {symobj.alias_with.name}",
                [None] * symobj.dimension,
                [""] * symobj.dimension,
                rc,
            )

        elif isinstance(symobj, UniverseAlias):
            ret = gmd.gmdAddSymbolXPy(
                write_to,
                symobj.name,
                symobj.dimension,
                gmd.GMS_DT_ALIAS,
                -1,
                f"Aliased with {symobj.alias_with}",
                [None] * symobj.dimension,
                [""] * symobj.dimension,
                rc,
            )

        # all other symbols
        else:
            if symobj.records is None:
                if isinstance(symobj, (Set, Parameter)):
                    df = pd.DataFrame(columns=list(range(0, symobj.dimension + 1)))
                elif isinstance(symobj, (Variable, Equation)):
                    df = pd.DataFrame(columns=list(range(0, symobj.dimension + 5)))

                # GMD merge operation
                if symname.casefold() in merge_symbols_cf:
                    # find symbol pointer
                    symPtr = gmd.gmdFindSymbolPy(write_to, symname, rc)

                    # fill symbol
                    container._gams2np.gmdFillSymbolStr(
                        write_to,
                        symPtr,
                        df.to_numpy(),
                        merge=True,
                        relaxedType=False,
                    )

                # GMD replace operation
                elif symname in syms and symname.casefold() not in merge_symbols_cf:
                    # find symbol pointer
                    symPtr = gmd.gmdFindSymbolPy(write_to, symname, rc)

                    # clear symbol records
                    ret = gmd.gmdClearSymbol(write_to, symPtr)
                    assert ret == 1

                    # fill symbol
                    container._gams2np.gmdFillSymbolStr(
                        write_to,
                        symPtr,
                        df.to_numpy(),
                        merge=False,
                        relaxedType=False,
                    )

                # NEW gmd symbol
                else:
                    # create new symbol
                    if symobj.domain_type == "regular":
                        gmd.gmdAddSymbolXPy(
                            write_to,
                            symname,
                            symobj.dimension,
                            symobj._gams_type,
                            symobj._gams_subtype,
                            symobj.description,
                            [
                                gmd.gmdFindSymbolPy(write_to, i, rc)
                                for i in symobj.domain_names
                            ],
                            symobj.domain_names,
                            rc,
                        )

                    elif symobj.domain_type == "relaxed":
                        gmd.gmdAddSymbolXPy(
                            write_to,
                            symname,
                            symobj.dimension,
                            symobj._gams_type,
                            symobj._gams_subtype,
                            symobj.description,
                            [None] * symobj.dimension,
                            symobj.domain_names,
                            rc,
                        )

                    elif symobj.domain_type == "none":
                        gmd.gmdAddSymbolXPy(
                            write_to,
                            symname,
                            symobj.dimension,
                            symobj._gams_type,
                            symobj._gams_subtype,
                            symobj.description,
                            [None] * symobj.dimension,
                            ["*"] * symobj.dimension,
                            rc,
                        )

                    # find symbol pointer
                    symPtr = gmd.gmdFindSymbolPy(write_to, symname, rc)

                    # fill new symbol
                    container._gams2np.gmdFillSymbolStr(
                        write_to,
                        symPtr,
                        df.to_numpy(),
                        merge=False,
                        relaxedType=False,
                    )

            else:
                # gmd merge operation
                if symname.casefold() in merge_symbols_cf:
                    # find symbol pointer
                    symPtr = gmd.gmdFindSymbolPy(write_to, symname, rc)

                    try:
                        container._gams2np.gmdFillSymbolStr(
                            write_to,
                            symPtr,
                            symobj.records.to_numpy(),
                            merge=True,
                            relaxedType=False,
                        )

                    except Exception as err:
                        # clear symbol records
                        ret = gmd.gmdClearSymbol(write_to, symPtr)

                        if str(err).startswith(
                            "Error writing symbol: Label exceeds maximum size of"
                        ):
                            raise Exception(
                                f"Error encountered when writing symbol `{symname}`. "
                                "Encountered a long UEL (i.e., >=64 characters): "
                                f"`{str(err).split('>')[1].split('<')[0]}` \n\n"
                                "Must shorten all long UELs."
                                f"Symbol `{symname}` was not created successfully in the GMD database."
                            )
                        elif re.search("exists already for symbol", str(err)):
                            raise Exception(
                                f"Error encountered when writing symbol `{symname}`. "
                                f"Encountered a duplicate record at UEL: ("
                                + str(err).split("(")[1].split(")")[0]
                                + ") \n\n"
                                "Must resolve all duplicate records before continuing. "
                                f"Symbol `{symname}` was not created successfully in the GMD database."
                            )
                        else:
                            raise err

                # gmd replace operation
                elif symname in syms and symname.casefold() not in merge_symbols_cf:
                    # find symbol pointer
                    symPtr = gmd.gmdFindSymbolPy(write_to, symname, rc)

                    ret = gmd.gmdClearSymbol(write_to, symPtr)
                    assert ret == 1

                    try:
                        container._gams2np.gmdFillSymbolStr(
                            write_to,
                            symPtr,
                            symobj.records.to_numpy(),
                            merge=False,
                            relaxedType=False,
                        )

                    except Exception as err:
                        # clear symbol records
                        ret = gmd.gmdClearSymbol(write_to, symPtr)

                        if str(err).startswith(
                            "Error writing symbol: Label exceeds maximum size of"
                        ):
                            raise Exception(
                                f"Error encountered when writing symbol `{symname}`. "
                                "Encountered a long UEL (i.e., >=64 characters): "
                                f"`{str(err).split('>')[1].split('<')[0]}` \n\n"
                                "Must shorten all long UELs."
                                f"Symbol `{symname}` was not created successfully in the GMD database."
                            )
                        elif re.search("exists already for symbol", str(err)):
                            raise Exception(
                                f"Error encountered when writing symbol `{symname}`. "
                                f"Encountered a duplicate record at UEL: ("
                                + str(err).split("(")[1].split(")")[0]
                                + ") \n\n"
                                "Must resolve all duplicate records before continuing. "
                                f"Symbol `{symname}` was not created successfully in the GMD database."
                            )
                        else:
                            raise err

                # gmd create new symbol
                else:
                    if symobj.domain_type == "regular":
                        gmd.gmdAddSymbolXPy(
                            write_to,
                            symname,
                            symobj.dimension,
                            symobj._gams_type,
                            symobj._gams_subtype,
                            symobj.description,
                            [
                                gmd.gmdFindSymbolPy(write_to, i, rc)
                                for i in symobj.domain_names
                            ],
                            symobj.domain_names,
                            rc,
                        )

                    elif symobj.domain_type == "relaxed":
                        gmd.gmdAddSymbolXPy(
                            write_to,
                            symname,
                            symobj.dimension,
                            symobj._gams_type,
                            symobj._gams_subtype,
                            symobj.description,
                            [None] * symobj.dimension,
                            symobj.domain_names,
                            rc,
                        )

                    elif symobj.domain_type == "none":
                        gmd.gmdAddSymbolXPy(
                            write_to,
                            symname,
                            symobj.dimension,
                            symobj._gams_type,
                            symobj._gams_subtype,
                            symobj.description,
                            [None] * symobj.dimension,
                            ["*"] * symobj.dimension,
                            rc,
                        )
                    else:
                        raise Exception(
                            "Encountered unknown domain_type while writing to GMD database."
                        )

                    # find symbol pointer
                    symPtr = gmd.gmdFindSymbolPy(write_to, symname, rc)

                    # fill new symbol
                    try:
                        container._gams2np.gmdFillSymbolStr(
                            write_to,
                            symPtr,
                            symobj.records.to_numpy(),
                            merge=False,
                            relaxedType=False,
                        )

                    except Exception as err:
                        # clear symbol records
                        ret = gmd.gmdClearSymbol(write_to, symPtr)

                        if str(err).startswith(
                            "Error writing symbol: Label exceeds maximum size of"
                        ):
                            raise Exception(
                                f"Error encountered when writing symbol `{symname}`. "
                                "Encountered a long UEL (i.e., >=64 characters): "
                                f"`{str(err).split('>')[1].split('<')[0]}` \n\n"
                                "Must shorten all long UELs."
                                f"Symbol `{symname}` was not created successfully in the GMD database."
                            )
                        elif re.search("exists already for symbol", str(err)):
                            raise Exception(
                                f"Error encountered when writing symbol `{symname}`. "
                                f"Encountered a duplicate record at UEL: ("
                                + str(err).split("(")[1].split(")")[0]
                                + ") \n\n"
                                "Must resolve all duplicate records before continuing. "
                                f"Symbol `{symname}` was not created successfully in the GMD database."
                            )
                        else:
                            raise err

    # reset GMD special values
    gmd.gmdSetSpecialValues(write_to, save_spec_values)
    gmd.delete_intp(rc)
