#
# GAMS - General Algebraic Modeling System Python API
#
# Copyright (c) 2017-2023 GAMS Development Corp. <support@gams.com>
# Copyright (c) 2017-2023 GAMS Software GmbH <support@gams.com>
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
#

import os
from warnings import warn
import pandas as pd
from gams.core import gdx
import gams.transfer._abcs as abcs
from gams.transfer.syms import (
    Set,
    Parameter,
    Variable,
    Equation,
    Alias,
    UniverseAlias,
)


from gams.transfer._internals import (
    SpecialValues,
    GamsSymbolTuple,
    GamsSymbol,
    DomainStatus,
    TRANSFER_TYPE,
)


def container_read(container, load_from, symbols, records):
    # test dll connection and create gdxhandle
    try:
        gdxHandle = gdx.new_gdxHandle_tp()
        rc = gdx.gdxCreateD(gdxHandle, container.system_directory, gdx.GMS_SSSIZE)
        assert rc[0], rc[1]

        ret, fileVersion, producer = gdx.gdxFileVersion(gdxHandle)

    except:
        raise Exception("Could not properly load GDX DLL, check system_directory path")

    # open file for reading
    rc = gdx.gdxOpenRead(gdxHandle, load_from)
    assert rc
    ret, symCount, _ = gdx.gdxSystemInfo(gdxHandle)

    # setting special values
    specVals = gdx.doubleArray(gdx.GMS_SVIDX_MAX)
    specVals[gdx.GMS_SVIDX_UNDEF] = SpecialValues.UNDEF
    specVals[gdx.GMS_SVIDX_NA] = SpecialValues.NA
    specVals[gdx.GMS_SVIDX_EPS] = SpecialValues.EPS
    specVals[gdx.GMS_SVIDX_PINF] = SpecialValues.POSINF
    specVals[gdx.GMS_SVIDX_MINF] = SpecialValues.NEGINF

    rc = gdx.gdxSetSpecialValues(gdxHandle, specVals)
    assert rc

    # check for acronyms
    n_acronyms = gdx.gdxAcronymCount(gdxHandle)
    if n_acronyms > 0:
        warn(
            "GDX file contains acronyms. "
            + "Acronyms are not supported and are set to GAMS NA."
        )

    acronyms = []
    for i in range(n_acronyms):
        ret, acr_name, acr_text, acr_idx = gdx.gdxAcronymGetInfo(gdxHandle, i + 1)
        acronyms.append(acr_idx)

    # get names of all symbols in the GDX file
    syms = []
    for i in range(1, symCount + 1):
        ret, syid, dimen, typ = gdx.gdxSymbolInfo(gdxHandle, i)
        syms.append(syid)

    if symbols is None:
        read_symbols = syms
    else:
        cf_syms = list(map(str.casefold, syms))
        for i in symbols:
            if i.casefold() not in cf_syms:
                raise ValueError(
                    f"User specified to read symbol `{i}`, "
                    "but it does not exist in the GDX file."
                )

        read_symbols = symbols

    # check if there are any duplicate symbols in the container
    for i in read_symbols:
        if i in container:
            raise Exception(
                f"Attempting to create a new symbol (through a read operation) named `{i}` "
                "but an object with this name already exists in the Container. "
                "Symbol replacement is only possible if the existing symbol is "
                "first removed from the Container with the `<container>.removeSymbols()` method."
            )

    # read metadata / create symbol objects
    cf_read_symbols = list(map(str.casefold, read_symbols))
    for i in range(1, symCount + 1):
        ret, syid, dimen, typ = gdx.gdxSymbolInfo(gdxHandle, i)

        if syid.casefold() in cf_read_symbols:
            synr, nrecs, userinfo, expltxt = gdx.gdxSymbolInfoX(gdxHandle, i)
            _, parent_set, _, _ = gdx.gdxSymbolInfo(gdxHandle, userinfo)

            ret, nrRecs = gdx.gdxDataReadRawStart(gdxHandle, i)
            domain_type, domain = gdx.gdxSymbolGetDomainX(gdxHandle, i)

            # gdx specific adjustment for equations
            if typ == 3:
                userinfo = userinfo - gdx.GMS_EQU_USERINFO_BASE

            # recast as necessary
            typ, userinfo = GamsSymbolTuple((typ, userinfo)).value

            # test for type
            if GamsSymbolTuple((typ, userinfo)) is GamsSymbolTuple.UNKNOWN:
                raise Exception(
                    f"Unknown GDX symbol classification (GAMS Type= {typ}, GAMS Subtype= {userinfo}). ",
                    f"Cannot load symbol `{syid}`",
                )

            # create the symbols in the container
            if GamsSymbol[GamsSymbolTuple((typ, userinfo)).name] is GamsSymbol.ALIAS:
                if parent_set in read_symbols:
                    Alias(container, syid, container.data[parent_set])
                else:
                    raise Exception(
                        (
                            f"Cannot create the Alias symbol `{syid}` "
                            f"because the parent set (`{parent_set}`) is not "
                            "being read into the in the Container. "
                            "Alias symbols require the parent set object to exist in the Container. "
                            f"Add `{parent_set}` to the list of symbols to read."
                        )
                    )

            elif (
                GamsSymbol[GamsSymbolTuple((typ, userinfo)).name]
                is GamsSymbol.UNIVERSE_ALIAS
            ):
                UniverseAlias(container, syid)

            elif GamsSymbol[GamsSymbolTuple((typ, userinfo)).name] is GamsSymbol.SET:
                Set(
                    container,
                    syid,
                    domain,
                    is_singleton=False,
                    description=expltxt,
                )

            elif (
                GamsSymbol[GamsSymbolTuple((typ, userinfo)).name]
                is GamsSymbol.SINGLETON_SET
            ):
                Set(
                    container,
                    syid,
                    domain,
                    is_singleton=True,
                    description=expltxt,
                )
            elif (
                GamsSymbol[GamsSymbolTuple((typ, userinfo)).name]
                is GamsSymbol.PARAMETER
            ):
                Parameter(container, syid, domain, description=expltxt)

            elif (
                GamsSymbol[GamsSymbolTuple((typ, userinfo)).name] in GamsSymbol.VARIABLE
            ):
                Variable(
                    container,
                    syid,
                    TRANSFER_TYPE[GamsSymbol[GamsSymbolTuple((typ, userinfo)).name]],
                    domain,
                    description=expltxt,
                )

            elif (
                GamsSymbol[GamsSymbolTuple((typ, userinfo)).name] in GamsSymbol.EQUATION
            ):
                Equation(
                    container,
                    syid,
                    TRANSFER_TYPE[GamsSymbol[GamsSymbolTuple((typ, userinfo)).name]],
                    domain,
                    description=expltxt,
                )

    # main records read
    if records == True:
        # get and store uels
        uels = container._gams2np.gdxGetUelList(gdxHandle)
        uels.remove("?L__0")
        uels.insert(0, "*")

        for n in read_symbols:
            if not isinstance(container[n], abcs.AnyContainerAlias):
                # do the read
                df = pd.DataFrame(
                    container._gams2np.gdxReadSymbolStr(gdxHandle, n, uels)
                )

                # set the records
                if not df.empty:
                    # create categorical
                    for x in range(len(df.columns)):
                        if x < container[n].dimension:
                            df.isetitem(
                                x,
                                df.iloc[:, x].astype(
                                    pd.CategoricalDtype(
                                        categories=df.iloc[:, x].unique(),
                                        ordered=True,
                                    ),
                                ),
                            )
                        else:
                            if isinstance(container[n], Set):
                                df.isetitem(x, df.iloc[:, x].astype(str))
                            else:
                                df.isetitem(x, df.iloc[:, x].astype(float))

                    container[n].records = df

                    # set column names
                    container[n].domain_labels = container[n].domain_names

                    # remap any acronyms to SpecialValues.NA
                    if len(acronyms) != 0:
                        if isinstance(
                            container[n],
                            (abcs.ABCParameter, abcs.ABCVariable, abcs.ABCEquation),
                        ):
                            for x in range(len(container[n].records.columns)):
                                if x >= container[n].dimension:
                                    for a in acronyms:
                                        idx = (
                                            container[n]
                                            .records.iloc[:, x][
                                                container[n].records.iloc[:, x]
                                                == a * 1e301
                                            ]
                                            .index
                                        )
                                        container[n].records.iloc[
                                            idx, x
                                        ] = SpecialValues.NA
                else:
                    container[n].records = None

        # link domain objects and categories
        container._linkDomainObjects(read_symbols)

    # close file
    gdx.gdxClose(gdxHandle)
    gdx.gdxFree(gdxHandle)
    gdx.gdxLibraryUnload()


def container_write(container, write_to, symbols, uel_priority, compress):
    # reorder symbols if necessary
    if container._isValidSymbolOrder() == False:
        container.reorderSymbols()

    # set defaults for symbols
    if symbols is None:
        symbols = container.listSymbols()

    # get symbol objects to write
    symobjs = container.getSymbols(symbols)
    symnames = [sym.name for sym in symobjs]

    # check symbols
    for symobj in symobjs:
        if not symobj.isValid():
            raise Exception(
                f"Cannot write to GDX because symbol `{symobj.name}` is invalid. "
                "Use `<symbol>.isValid(verbose=True)` to debug."
            )

    # create gdxHandle
    gdxHandle = gdx.new_gdxHandle_tp()
    rc, msg = gdx.gdxCreateD(gdxHandle, container.system_directory, gdx.GMS_SSSIZE)
    if not rc:
        raise Exception(msg)

    # open GDX for writing
    if compress == False:
        if not gdx.gdxOpenWrite(gdxHandle, write_to, "GAMS Transfer")[0]:
            raise Exception(f"Error opening GDX `{write_to}` for writing")
    else:
        if not gdx.gdxOpenWriteEx(gdxHandle, write_to, "GAMS Transfer", 1)[0]:
            raise Exception(
                f"Error opening GDX (w/compression) `{write_to}` for writing"
            )

    # setting special values
    specVals = gdx.doubleArray(gdx.GMS_SVIDX_MAX)
    specVals[gdx.GMS_SVIDX_UNDEF] = SpecialValues.UNDEF
    specVals[gdx.GMS_SVIDX_NA] = SpecialValues.NA
    specVals[gdx.GMS_SVIDX_EPS] = SpecialValues.EPS
    specVals[gdx.GMS_SVIDX_PINF] = SpecialValues.POSINF
    specVals[gdx.GMS_SVIDX_MINF] = SpecialValues.NEGINF

    rc = gdx.gdxSetSpecialValues(gdxHandle, specVals)
    assert rc

    #
    # register the UniverseSet
    # no reorder
    if uel_priority is None:
        gdx.gdxUELRegisterRawStart(gdxHandle)
        [gdx.gdxUELRegisterRaw(gdxHandle, i) for i in container.getUELs()]
        gdx.gdxUELRegisterDone(gdxHandle)

    else:
        gdx.gdxUELRegisterRawStart(gdxHandle)

        # register uel_priority first
        [gdx.gdxUELRegisterRaw(gdxHandle, i) for i in uel_priority]

        # register rest of universe
        [gdx.gdxUELRegisterRaw(gdxHandle, i) for i in container.getUELs()]

        gdx.gdxUELRegisterDone(gdxHandle)

    # capture container modified state
    orig_container_modified = container.modified

    # check if symbol domains are also being written -- if not, relax the domain for writing
    # retain the string set label, do not relax to "*" domains
    was_relaxed = {}
    for symobj in symobjs:
        if symobj.domain_type == "regular":
            if any(not domsymobj in symobjs for domsymobj in symobj.domain):
                was_relaxed[symobj.name] = {
                    "object": symobj,
                    "domain": symobj.domain,
                    "modified": symobj.modified,
                }

                # relax the domain
                symobj.domain = [
                    dom.name if isinstance(dom, abcs.AnyContainerSymbol) else dom
                    for dom in symobj.domain
                ]

    #
    # attempt the write
    try:
        for symname, symobj in zip(symnames, symobjs):
            if isinstance(symobj, abcs.ABCAlias):
                gdx.gdxAddAlias(gdxHandle, symobj.alias_with.name, symname)

            elif isinstance(symobj, abcs.ABCUniverseAlias):
                gdx.gdxAddAlias(gdxHandle, "*", symname)

            else:
                if symobj.records is None:
                    df = pd.DataFrame(
                        columns=[f"dim{i}" for i in range(symobj.dimension)]
                        + symobj._attributes
                    )

                    # adjust equation userinfo for GDX
                    if isinstance(symobj, abcs.ABCEquation):
                        symobj._gams_subtype = (
                            symobj._gams_subtype + gdx.GMS_EQU_USERINFO_BASE
                        )

                    if symobj._domain_status is DomainStatus.regular:
                        container._gams2np.gdxWriteSymbolStr(
                            gdxHandle,
                            symname,
                            symobj.description,
                            symobj.dimension,
                            symobj._gams_type,
                            symobj._gams_subtype,
                            df.to_numpy(),
                            symobj.domain_names,
                        )
                    elif symobj._domain_status is DomainStatus.relaxed:
                        container._gams2np.gdxWriteSymbolStr(
                            gdxHandle,
                            symname,
                            symobj.description,
                            symobj.dimension,
                            symobj._gams_type,
                            symobj._gams_subtype,
                            df.to_numpy(),
                            ["*"] * symobj.dimension,
                        )
                    elif symobj._domain_status is DomainStatus.none:
                        container._gams2np.gdxWriteSymbolStr(
                            gdxHandle,
                            symname,
                            symobj.description,
                            symobj.dimension,
                            symobj._gams_type,
                            symobj._gams_subtype,
                            df.to_numpy(),
                        )

                else:
                    # power write
                    if symobj._domain_status is DomainStatus.regular:
                        try:
                            container._gams2np.gdxWriteSymbolStr(
                                gdxHandle,
                                symname,
                                symobj.description,
                                symobj.dimension,
                                symobj._gams_type,
                                symobj._gams_subtype,
                                symobj.records.to_numpy(),
                                symobj.domain_names,
                            )
                        except Exception as err:
                            raise Exception(
                                f"Error encountered when writing symbol `{symname}`. "
                                "Possible cause is that a UEL is >= 64 characters long, must shorten all long UELs. "
                                f"[GDX Error: '{err}']. \n\n"
                                "GDX file was not created successfully."
                            )

                    elif symobj._domain_status is DomainStatus.relaxed:
                        try:
                            container._gams2np.gdxWriteSymbolStr(
                                gdxHandle,
                                symname,
                                symobj.description,
                                symobj.dimension,
                                symobj._gams_type,
                                symobj._gams_subtype,
                                symobj.records.to_numpy(),
                                ["*"] * symobj.dimension,
                            )
                        except Exception as err:
                            raise Exception(
                                f"Error encountered when writing symbol `{symname}`. "
                                "Possible cause is that a UEL is >= 64 characters long, must shorten all long UELs. "
                                f"[GDX Error: '{err}']. \n\n"
                                "GDX file was not created successfully."
                            )
                    elif symobj._domain_status is DomainStatus.none:
                        try:
                            container._gams2np.gdxWriteSymbolStr(
                                gdxHandle,
                                symname,
                                symobj.description,
                                symobj.dimension,
                                symobj._gams_type,
                                symobj._gams_subtype,
                                symobj.records.to_numpy(),
                            )
                        except Exception as err:
                            raise Exception(
                                f"Error encountered when writing symbol `{symname}`. "
                                "Possible cause is that a UEL is >= 64 characters long, must shorten all long UELs. "
                                f"[GDX Error: '{err}']. \n\n"
                                "GDX file was not created successfully."
                            )

            current_error_count = gdx.gdxDataErrorCount(gdxHandle)

            if current_error_count != 0:
                raise Exception(
                    f"Encountered data errors with symbol `{symname}`. "
                    "Possible causes are from duplicate records and/or domain violations. \n\n"
                    "Use 'hasDuplicateRecords', 'findDuplicateRecords', 'dropDuplicateRecords', "
                    "and/or 'countDuplicateRecords' to find/resolve duplicate records. \n"
                    "Use 'hasDomainViolations', 'findDomainViolations', 'dropDomainViolations', "
                    "and/or 'countDomainViolations' to find/resolve domain violations. \n\n"
                    "GDX file was not created successfully."
                )

        # assign relaxed domains
        for symname, symobj in zip(symnames, symobjs):
            if symobj.domain_type == "relaxed":
                ret, synr = gdx.gdxFindSymbol(gdxHandle, symname)
                assert (
                    ret
                ), f"Symbol `{symname}` not found in GDX when writing relaxed domain information"
                gdx.gdxSymbolSetDomainX(gdxHandle, synr, symobj.domain_names)

    except Exception as err:
        # close file
        gdx.gdxClose(gdxHandle)
        gdx.gdxFree(gdxHandle)
        gdx.gdxLibraryUnload()

        # delete file
        if os.path.exists(write_to):
            os.remove(write_to)

        # raise error
        raise err

    finally:
        # restore domains in the Container
        for _, properties in was_relaxed.items():
            symobj = properties["object"]
            symobj._domain = properties["domain"]
            symobj._modified = properties["modified"]

        # reset container modified flag
        container._modified = orig_container_modified

    # auto convert file and close
    gdx.gdxAutoConvert(gdxHandle, 0)
    gdx.gdxClose(gdxHandle)
    gdx.gdxFree(gdxHandle)
    gdx.gdxLibraryUnload()
