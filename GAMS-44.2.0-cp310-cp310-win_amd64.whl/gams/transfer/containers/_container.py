#
# GAMS - General Algebraic Modeling System Python API
#
# Copyright (c) 2017-2023 GAMS Development Corp. <support@gams.com>
# Copyright (c) 2017-2023 GAMS Software GmbH <support@gams.com>
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
#

import os
import pandas as pd
import numpy as np
import gams.numpy as gnp
from gams import GamsWorkspace, GamsDatabase
from gams.core import gmd
from gams.transfer._internals import CasePreservingDict, DestinationType
import gams.transfer._abcs as abcs
from gams.transfer.containers._mixins import CCCMixin
import gams.transfer.containers._io as io
from gams.transfer.syms import Set, Parameter, Variable, Equation, Alias, UniverseAlias
import logging

logging.basicConfig(
    format="[%(levelname)s - %(asctime)s]\n%(message)s", level=logging.INFO
)


def get_system_directory(system_directory):
    if system_directory is None:
        try:
            ws = GamsWorkspace()
            system_directory = ws.system_directory
        except:
            raise Exception(
                "Could not find a GAMS installation, "
                "must manually specify system_directory"
            )
    elif not os.path.isabs(system_directory):
        raise Exception(
            "Must enter valid full (absolute) path to GAMS system_directory"
        )

    return system_directory


class Container(CCCMixin, abcs.ABCContainer):
    def __init__(self, load_from=None, system_directory=None):
        # set up
        self.system_directory = get_system_directory(system_directory)
        self._gams_compiler_path = "gams"
        self._gams2np = gnp.Gams2Numpy(self.system_directory)
        self.data = CasePreservingDict()
        self._statements_dict = CasePreservingDict()
        self._unsaved_statements = CasePreservingDict()
        self.modified = True
        self._requires_state_check = True

        # read
        if load_from is not None:
            self.read(load_from)

    def __iter__(self):
        return iter(self.data.items())

    def __repr__(self):
        return f"<GAMS Transfer Container ({hex(id(self))})>"

    def __str__(self):
        if len(self):
            return f"<GAMS Transfer Container (w/ {len(self)} symbols)>"
        else:
            return f"<GAMS Transfer Container (empty)>"

    def __getitem__(self, sym):
        try:
            return self.data[sym]
        except KeyError:
            return KeyError(
                f"Attempted retrieval of symbol `{sym}`, but `{sym}` does not exist in the Container"
            )

    def __contains__(self, sym):
        if isinstance(sym, abcs.AnyContainerSymbol):
            return hex(id(sym)) in [hex(id(i)) for i in self.data.values()]
        elif isinstance(sym, str):
            return sym in self.data
        else:
            return False

    def getUELs(self, symbols=None, ignore_unused=False):
        if not isinstance(symbols, (str, list, type(None))):
            raise Exception("Argument 'symbols' must be type str, list or NoneType.")

        if symbols is None:
            symbols = self.listSymbols(is_valid=True)

        if isinstance(symbols, str):
            symbols = [symbols]

        if not isinstance(ignore_unused, bool):
            raise TypeError(f"Argument 'ignore_unused' must be type bool")

        if any(not isinstance(i, str) for i in symbols):
            raise Exception(("Argument 'symbols' must only contain type str"))

        # loop through symbol objects
        uni = pd.Index([], dtype="object")
        for symobj in self.getSymbols(symbols):
            if not isinstance(symobj, abcs.ABCUniverseAlias):
                add_uels = symobj.getUELs(ignore_unused=ignore_unused)

                if add_uels is not None:
                    uni = uni.union(
                        pd.Index(
                            symobj.getUELs(ignore_unused=ignore_unused), dtype="object"
                        ),
                        sort=False,
                    )

        return uni.tolist()

    def renameUELs(self, uels, symbols=None, allow_merge=False):
        if not self.isValid():
            raise Exception(
                "Container is currently invalid -- must be valid in order to access UELs (categories)."
            )

        # ARG: uels
        if not isinstance(uels, dict):
            raise TypeError("Argument 'uels' must be type dict")

        # ARG: symbols
        if not isinstance(symbols, (list, type(None))):
            raise TypeError("Argument 'symbols' must be type list or NoneType")

        if symbols is None:
            symbols = list(self.data.keys())

        if isinstance(symbols, list):
            if any(not isinstance(i, str) for i in symbols):
                raise TypeError("Argument 'symbols' must contain only type str")

        for symobj in self.getSymbols(symbols):
            if not isinstance(symobj, abcs.ABCUniverseAlias):
                symobj.renameUELs(uels, allow_merge=allow_merge)

    def removeUELs(self, uels=None, symbols=None):
        if not self.isValid():
            raise Exception(
                "Container is currently invalid -- must be valid in order to access UELs (categories)."
            )

        if not isinstance(uels, (list, str, type(None))):
            raise TypeError("Argument 'uels' must be type list, str or NoneType")

        if isinstance(uels, str):
            uels = [uels]

        if isinstance(uels, list):
            if any(not isinstance(i, str) for i in uels):
                raise TypeError("Argument 'uels' must contain only type str")

        if not isinstance(symbols, (list, type(None))):
            raise TypeError("Argument 'symbols' must be type list or NoneType")

        if symbols is None:
            symbols = list(self.data.keys())

        if isinstance(symbols, list):
            if any(not isinstance(i, str) for i in symbols):
                raise TypeError("Argument 'symbols' must contain only type str")

        for symobj in self.getSymbols(symbols):
            if not isinstance(symobj, abcs.ABCUniverseAlias):
                symobj.removeUELs(uels)

    def getDomainViolations(self):
        dvs = []
        for symname, symobj in self:
            violations = symobj.getDomainViolations()
            if violations is not None:
                dvs.extend(violations)

        if len(dvs) != 0:
            return dvs
        else:
            return None

    def hasDomainViolations(self):
        return any(symobj.hasDomainViolations() for symnam, symobj in self)

    def countDomainViolations(self):
        dvs = {}

        for symname, symobj in self:
            count = symobj.countDomainViolations()
            if count != 0:
                dvs.update({symname: count})

        return dvs

    def dropDomainViolations(self):
        for symobj in self.getSymbols(self.countDomainViolations().keys()):
            symobj.records.drop(index=symobj.findDomainViolations().index, inplace=True)

    def countDuplicateRecords(self):
        dups = {}

        for symname, symobj in self:
            count = symobj.countDuplicateRecords()
            if count != 0:
                dups.update({symname: count})

        return dups

    def hasDuplicateRecords(self):
        return any(symobj.hasDuplicateRecords() for symname, symobj in self)

    def dropDuplicateRecords(self, keep="first"):
        for symobj in self.getSymbols(self.countDuplicateRecords().keys()):
            symobj.records.drop(
                index=symobj.findDuplicateRecords(keep).index, inplace=True
            )

    def _assert_is_valid(self):
        if self._requires_state_check:
            # make sure that all symbols have consistent naming
            for symname, symobj in self:
                if symname != symobj.name:
                    raise Exception(
                        "Container data dict key is inconsistent "
                        f"with the symbol object name (`{symname}` != `{symobj.name}`). "
                        "This inconsistency could have resulted from a symbol "
                        "copy/deepcopy operation (i.e., `m[<new_symbol>] = copy.deepcopy(m[<existing_symbol>])`). "
                        "Update symbol name with `<new_symbol>.name`."
                    )

            # make sure that all symbols reference the correct Container instance
            for symname, symobj in self:
                if self != symobj.ref_container:
                    raise Exception(
                        f"Symbol `{symname}` has a broken Container reference. "
                        f"Symbol references Container at {hex(id(symobj.ref_container))} "
                        f"-- should be referencing Container at {hex(id(self))}. "
                        "This inconsistency could have resulted from a `deepcopy` "
                        "of a symbol object (i.e., `new_container[<symbol>] = copy.deepcopy(old_container[<symbol>])`). "
                        "Update symbol reference with `<symbol>.ref_container = <new_container>`."
                    )

            if self.listSymbols() != self.listSymbols(is_valid=True):
                raise Exception(
                    "Container contains invalid symbols; invalid "
                    "symbols can be found with the "
                    "`<container>.listSymbols(is_valid=False)` method. Debug invalid "
                    "symbol(s) by running `<symbol>.isValid(verbose=True, force=True)`` "
                    "method on the symbol object."
                )

            # check if there are graph cycles in the sets
            try:
                self._validSymbolOrder()
            except Exception as err:
                raise err

            # if no exceptions, then turn self._requires_state_check 'off'
            self._requires_state_check = False

    @property
    def modified(self):
        return self._modified

    @modified.setter
    def modified(self, modified):
        if not isinstance(modified, bool):
            raise TypeError("Attribute 'modified' must be type bool")

        self._modified = modified

        if modified is False:
            for symname, symobj in self:
                symobj.modified = False

    def _validSymbolOrder(self):
        ordered_symbols = []
        symbols_to_sort = [k for k, _ in self]

        idx = 0
        while symbols_to_sort:
            sym = symbols_to_sort[idx]

            # special 1D sets (universe domain & relaxed sets)
            if (
                isinstance(self.data[sym], abcs.ABCSet)
                and self.data[sym].dimension == 1
                and isinstance(self.data[sym].domain[0], str)
            ):
                ordered_symbols.append(self.data[sym].name)
                symbols_to_sort.pop(symbols_to_sort.index(sym))
                idx = 0

            # everything else
            else:
                doi = []
                for i in self.data[sym].domain:
                    if isinstance(i, str):
                        doi.append(True)
                    elif (
                        isinstance(i, abcs.AnyContainerDomainSymbol)
                        and i.name in ordered_symbols
                    ):
                        doi.append(True)
                    else:
                        doi.append(False)

                if all(doi):
                    ordered_symbols.append(sym)
                    symbols_to_sort.pop(symbols_to_sort.index(sym))
                    idx = 0
                else:
                    idx += 1

            if idx == len(symbols_to_sort) and symbols_to_sort != []:
                raise Exception(
                    "Graph cycle detected among symbols: "
                    f"{[i for i in symbols_to_sort if isinstance(self.data[i], abcs.ABCSet)]} -- "
                    "must resolve circular domain referencing"
                )

        return ordered_symbols

    def reorderSymbols(self):
        self.data = CasePreservingDict(
            {k: self.data[k] for k in self._validSymbolOrder()}
        )

    def _isValidSymbolOrder(self):
        valid_order = self._validSymbolOrder()
        current_order = [k for k, _ in self]

        h = []
        for i in current_order:
            if isinstance(self.data[i], abcs.AnyContainerDomainSymbol):
                if current_order.index(i) <= valid_order.index(i):
                    h.append(True)
                else:
                    h.append(False)
            else:
                h.append(True)

        if all(h):
            return True
        else:
            return False

    def renameSymbol(self, old_name, new_name):
        if not isinstance(old_name, str):
            raise Exception("Argument 'old_name' must be type str")

        if not isinstance(new_name, str):
            raise Exception("Argument 'new_name' must be type str")

        if old_name.casefold() not in self:
            raise KeyError(f"Symbol `{old_name}` does not exist")

        if old_name.casefold() != new_name.casefold():
            self.data[old_name].name = new_name
            self._requires_state_check = True

    def _linkDomainObjects(self, symbols):
        for i in symbols:
            if not isinstance(self.data[i], abcs.AnyContainerAlias):
                d = []
                for j in self.data[i].domain:
                    if j == i:
                        d.append(j)
                    elif j in symbols and j != i:
                        d.append(self.data[j])
                    else:
                        d.append(j)

                # do the relink
                self.data[i].domain = d

    def removeSymbols(self, symbols):
        # ARG: symbols
        if not isinstance(symbols, (str, list)):
            raise Exception("Argument 'symbols' must be type str or list")

        if isinstance(symbols, str):
            symbols = [symbols]

        if not all([isinstance(i, str) for i in symbols]):
            raise Exception("Argument 'symbols' must contain only type str")

        # test if all symbols are in the Container
        for i in symbols:
            if i not in self:
                raise ValueError(
                    f"User specified to remove symbol `{i}`, "
                    "but it does not exist in the container."
                )

        # find sets or aliases that are being removed
        set_or_alias = []
        [
            set_or_alias.append(symobj)
            for symobj in self.getSymbols(symbols)
            if isinstance(symobj, abcs.AnyContainerDomainSymbol)
        ]

        # remove symbols
        for symobj in self.getSymbols(symbols):
            # mark symbol ref_container as None and reset state check flag
            symobj._ref_container = None
            symobj._requires_state_check = True

            # remove the symbol
            self.data.pop(symobj.name)

        # remove alias symbols if parent is removed
        symbols = list(self)
        for symname, symobj in symbols:
            if isinstance(symobj, abcs.ABCAlias):
                if symobj.alias_with in set_or_alias:
                    self.removeSymbols(symobj.name)

        # search through all symbols and remove domain references
        for symname, symobj in self:
            # find new domain
            new_domain = []
            for n, symdom in enumerate(symobj.domain):
                if symdom in set_or_alias:
                    new_domain.append("*")
                else:
                    new_domain.append(symdom)

            # set new (relaxed) domain
            symobj.domain = new_domain

        # reset flags
        if set_or_alias:
            for symname, symobj in self:
                symobj._requires_state_check = True
                symobj.modified = True

        # reset state check flag for the container
        self._requires_state_check = True

    def addSet(
        self,
        name,
        domain=None,
        is_singleton=False,
        records=None,
        domain_forwarding=False,
        description="",
        uels_on_axes=False,
    ):
        if name not in self:
            obj = Set(
                self,
                name,
                domain,
                is_singleton,
                records,
                domain_forwarding,
                description,
                uels_on_axes,
            )

            return obj

        else:
            # try if argument formats are valid
            try:
                m = Container(system_directory=self.system_directory)
                obj = Set(
                    m,
                    name,
                    domain,
                    is_singleton,
                    records=None,
                    domain_forwarding=domain_forwarding,
                    description=description,
                )
            except (TypeError, ValueError, Exception) as err:
                raise err

            # domain handling
            if domain is None:
                domain = ["*"]

            if isinstance(domain, (Set, str)):
                domain = [domain]

            # allow records overwriting
            if (
                isinstance(self[name], Set)
                and self.data[name].domain == domain
                and self[name].is_singleton == is_singleton
                and self[name].domain_forwarding == domain_forwarding
            ):
                if records is not None:
                    self[name].setRecords(records)

                # only change the description if a new one is passed
                if description != "":
                    self[name].description = description

                return self[name]

            else:
                raise ValueError(
                    f"Attempting to add a symbol named `{name}` "
                    "but one already exists in the Container. "
                    "Symbol replacement is only possible if the symbol is "
                    "first removed from the Container with the removeSymbols() method. "
                    "Overwriting symbol 'records' and 'description' are possible if "
                    "all other properties have not changed."
                )

    def addParameter(
        self,
        name,
        domain=None,
        records=None,
        domain_forwarding=False,
        description="",
        uels_on_axes=False,
    ):
        if name not in self:
            obj = Parameter(
                self,
                name,
                domain,
                records,
                domain_forwarding,
                description,
                uels_on_axes,
            )
            return obj

        else:
            # try if argument formats are valid
            try:
                m = Container(system_directory=self.system_directory)
                obj = Parameter(
                    m,
                    name,
                    domain,
                    records=None,
                    domain_forwarding=domain_forwarding,
                    description=description,
                )
            except (TypeError, ValueError, Exception) as err:
                raise err

            # domain handling
            if domain is None:
                domain = []

            if isinstance(domain, (abcs.AnyContainerDomainSymbol, str)):
                domain = [domain]

            # allow records overwriting
            if (
                isinstance(self.data[name], Parameter)
                and self.data[name].domain == domain
                and self.data[name].domain_forwarding == domain_forwarding
            ):
                if records is not None:
                    self.data[name].setRecords(records)

                # only change the description if a new one is passed
                if description != "":
                    self.data[name].description = description

                return self.data[name]

            else:
                raise ValueError(
                    f"Attempting to add a symbol named `{name}` "
                    "but one already exists in the Container. "
                    "Symbol replacement is only possible if the symbol is "
                    "first removed from the Container with the removeSymbols() method. "
                    "Overwriting symbol 'records' and 'description' are possible if "
                    "all other properties have not changed."
                )

    def addVariable(
        self,
        name,
        type="free",
        domain=None,
        records=None,
        domain_forwarding=False,
        description="",
        uels_on_axes=False,
    ):
        if name not in self:
            obj = Variable(
                self,
                name,
                type,
                domain,
                records,
                domain_forwarding,
                description,
                uels_on_axes,
            )
            return obj

        else:
            # try if argument formats are valid
            try:
                m = Container(system_directory=self.system_directory)
                obj = Variable(
                    m,
                    name,
                    type,
                    domain,
                    records=None,
                    domain_forwarding=domain_forwarding,
                    description=description,
                )
            except (TypeError, ValueError, Exception) as err:
                raise err

            # domain handling
            if domain is None:
                domain = []

            if isinstance(domain, (abcs.AnyContainerDomainSymbol, str)):
                domain = [domain]

            # allow records overwriting
            if (
                isinstance(self.data[name], Variable)
                and self.data[name].type == type
                and self.data[name].domain == domain
                and self.data[name].domain_forwarding == domain_forwarding
            ):
                if records is not None:
                    self.data[name].setRecords(records)

                # only change the description if a new one is passed
                if description != "":
                    self.data[name].description = description

                return self.data[name]

            else:
                raise ValueError(
                    f"Attempting to add a symbol named `{name}` "
                    "but one already exists in the Container. "
                    "Symbol replacement is only possible if the symbol is "
                    "first removed from the Container with the removeSymbols() method. "
                    "Overwriting symbol 'records' and 'description' are possible if "
                    "all other properties have not changed."
                )

    def addEquation(
        self,
        name,
        type,
        domain=None,
        records=None,
        domain_forwarding=False,
        description="",
        uels_on_axes=False,
    ):
        if name not in self:
            obj = Equation(
                self,
                name,
                type,
                domain,
                records,
                domain_forwarding,
                description,
                uels_on_axes,
            )
            return obj

        else:
            # try if argument formats are valid
            try:
                m = Container(system_directory=self.system_directory)
                obj = Equation(
                    m,
                    name,
                    type,
                    domain,
                    records=None,
                    domain_forwarding=domain_forwarding,
                    description=description,
                )
            except (TypeError, ValueError, Exception) as err:
                raise err

            # domain handling
            if domain is None:
                domain = []

            if isinstance(domain, (abcs.AnyContainerDomainSymbol, str)):
                domain = [domain]

            # allow records overwriting
            if (
                isinstance(self.data[name], Equation)
                and self.data[name].type == type
                and self.data[name].domain == domain
                and self.data[name].domain_forwarding == domain_forwarding
            ):
                if records is not None:
                    self.data[name].setRecords(records)

                # only change the description if a new one is passed
                if description != "":
                    self.data[name].description = description

                return self.data[name]

            else:
                raise ValueError(
                    f"Attempting to add a symbol named `{name}` "
                    "but one already exists in the Container. "
                    "Symbol replacement is only possible if the symbol is "
                    "first removed from the Container with the removeSymbols() method. "
                    "Overwriting symbol 'records' and 'description' are possible if "
                    "all other properties have not changed."
                )

    def addAlias(self, name, alias_with):
        if name not in self:
            obj = Alias(self, name, alias_with)

            return obj

        else:
            if not isinstance(alias_with, (abcs.ABCSet, abcs.ABCAlias)):
                raise TypeError("Symbol 'alias_with' must be type Set or Alias")

            if isinstance(alias_with, abcs.ABCAlias):
                parent = alias_with
                while not isinstance(parent, Set):
                    parent = parent.alias_with
                alias_with = parent

            # allow overwriting
            if isinstance(self.data[name], abcs.ABCAlias):
                self.data[name].alias_with = alias_with

                return self.data[name]

            else:
                raise ValueError(
                    f"Attempting to add an Alias symbol named `{name}`, however "
                    "a symbol with this name but different type already exists in the Container. "
                    "Symbol replacement is only possible if this symbol is "
                    "first removed from the Container with the removeSymbols() method. "
                )

    def addUniverseAlias(self, name):
        if name not in self:
            obj = UniverseAlias(self, name)

            return obj

        else:
            # no overwriting necessary just return the object
            if isinstance(self.data[name], abcs.ABCUniverseAlias):
                return self.data[name]

            else:
                raise ValueError(
                    f"Attempting to add a UniverseAlias symbol named `{name}`, however "
                    "a symbol with this name but different type already exists in the Container. "
                    "Symbol replacement is only possible if this symbol is "
                    "first removed from the Container with the removeSymbols() method. "
                )

    def _gdx_read(self, load_from, symbols, records):
        return io.gdx.container_read(self, load_from, symbols, records)

    def _gdx_write(self, write_to, symbols, uel_priority, compress):
        return io.gdx.container_write(self, write_to, symbols, uel_priority, compress)

    def _gmd_read(self, load_from, symbols, records):
        return io.gmd.container_read(self, load_from, symbols, records)

    def _gmd_write(self, write_to, symbols, uel_priority, merge_symbols):
        return io.gmd.container_write(
            self, write_to, symbols, uel_priority, merge_symbols
        )

    def _container_constcontainer_read(self, load_from, symbols, records):
        return io.containers.read(self, load_from, symbols, records)

    def write(
        self,
        write_to,
        symbols=None,
        compress=False,
        uel_priority=None,
        merge_symbols=None,
    ):
        # check symbols argument
        if not isinstance(symbols, (str, list, type(None))):
            raise TypeError("Argument 'symbols' must be type str, list or NoneType")

        if isinstance(symbols, str):
            symbols = [symbols]

        if symbols is not None:
            if any(not isinstance(i, str) for i in symbols):
                raise TypeError("Argument 'symbols' must contain only type str")

        # check compress argument
        if not isinstance(compress, bool):
            raise TypeError(
                "Argument 'compress' must be of type bool; default "
                "False (no compression); ignored if writing to a GMD object."
            )

        # check uel_priority argument
        if not isinstance(uel_priority, (str, list, type(None))):
            raise TypeError(
                "Argument 'uel_priority' must be type str, list or NoneType"
            )

        if isinstance(uel_priority, str):
            uel_priority = [uel_priority]

        # check merge_symbols argument
        if not isinstance(merge_symbols, (str, list, type(None))):
            raise TypeError(
                "Argument 'merge_symbols' must be type str, list or NoneType"
            )

        if isinstance(merge_symbols, str):
            merge_symbols = [merge_symbols]

        if merge_symbols is None:
            merge_symbols = []

        if isinstance(merge_symbols, list):
            if any(not isinstance(i, str) for i in merge_symbols):
                raise TypeError("Argument 'merge_symbols' must contain only type str")

        #
        # figure out data write_to type
        if isinstance(write_to, GamsDatabase):
            dest = DestinationType.GMD
            write_to = write_to._gmd

        elif isinstance(write_to, str):
            if not write_to.endswith(".gdx"):
                raise Exception(
                    "Unexpected file type passed to 'write_to' argument "
                    "-- expected file extension '.gdx'"
                )

            dest = DestinationType.GDX

        else:
            # try GMD, if not, then mark as unknown
            try:
                ret = gmd.gmdInfo(write_to, gmd.GMD_NRSYMBOLSWITHALIAS)
                assert ret[0] == 1
                dest = DestinationType.GMD
            except:
                dest = DestinationType.UNKNOWN

        # throw error if user wants to merge symbols but write_to is not a GMD object
        if dest is DestinationType.GDX and len(merge_symbols) != 0:
            raise Exception(
                "Symbol merge operations are only possible when writing to a valid GMD object."
            )

        #
        # test and write to different destinations
        #
        if dest is DestinationType.UNKNOWN:
            raise TypeError(
                "Argument 'write_to' expects "
                "type str (i.e., a path to a GDX file) "
                "or a valid gmdHandle (or GamsDatabase instance) "
                f"User passed: '{type(write_to)}'."
            )

        # check if domains are valid
        for symname, symobj in self:
            if not isinstance(symobj, abcs.ABCUniverseAlias):
                if symobj.records is not None:
                    for i in range(symobj.dimension):
                        if np.any(symobj.records.iloc[:, i].cat.codes.to_numpy() == -1):
                            raise Exception(
                                f"Categories are missing from the data in symbol `{symname}` (dimension {i}) -- "
                                "has resulted in `NaN` domains labels. "
                                "Cannot write symbol until domain labels have been been restored."
                            )

        if dest is DestinationType.GDX:
            self._gdx_write(os.path.abspath(write_to), symbols, uel_priority, compress)

        if dest is DestinationType.GMD:
            self._gmd_write(write_to, symbols, uel_priority, merge_symbols)
