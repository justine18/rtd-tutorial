#
# GAMS - General Algebraic Modeling System Python API
#
# Copyright (c) 2017-2023 GAMS Development Corp. <support@gams.com>
# Copyright (c) 2017-2023 GAMS Software GmbH <support@gams.com>
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
#

import os
import pathlib
from collections.abc import Iterable
import pandas as pd
from gams.control import GamsDatabase
from gams.core import gmd
from gams.transfer._internals import (
    CasePreservingDict,
    SourceType,
    VAR_STR_TO_TYPE,
    EQU_STR_TO_TYPE,
)
import gams.transfer._abcs as abcs


class CCCMixin:
    @property
    def data(self):
        return self._data

    @data.setter
    def data(self, data):
        self._data = data

    def __len__(self):
        return len(self.data)

    def isValid(self, verbose=False, force=False):
        if not isinstance(verbose, bool):
            raise ValueError("Argument 'verbose' must be type bool")

        if not isinstance(force, bool):
            raise ValueError("Argument 'force' must be type bool")

        if force:
            self._requires_state_check = True

        if self._requires_state_check:
            try:
                self._assert_is_valid()
                return True
            except Exception as err:
                if verbose:
                    raise err
                return False
        else:
            return True

    def listSymbols(self, is_valid=None):
        if not isinstance(is_valid, (bool, type(None))):
            raise TypeError("Argument 'is_valid' must be type bool or NoneType")

        if is_valid is True:
            return [symname for symname, symobj in self if symobj.isValid()]
        elif is_valid is False:
            return [symname for symname, symobj in self if not symobj.isValid()]
        else:
            return [symname for symname, symobj in self]

    def listParameters(self, is_valid=None):
        if not isinstance(is_valid, (bool, type(None))):
            raise TypeError("Argument 'is_valid' must be type bool or NoneType")

        return [
            symobj.name
            for symobj in self.getSymbols(self.listSymbols(is_valid))
            if isinstance(symobj, abcs.ABCParameter)
        ]

    def listSets(self, is_valid=None):
        if not isinstance(is_valid, (bool, type(None))):
            raise TypeError("Argument 'is_valid' must be type bool or NoneType")

        return [
            symobj.name
            for symobj in self.getSymbols(self.listSymbols(is_valid))
            if isinstance(symobj, abcs.ABCSet)
        ]

    def listAliases(self, is_valid=None):
        if not isinstance(is_valid, (bool, type(None))):
            raise TypeError("Argument 'is_valid' must be type bool or NoneType")

        return [
            symobj.name
            for symobj in self.getSymbols(self.listSymbols(is_valid))
            if isinstance(symobj, (abcs.ABCAlias, abcs.ABCUniverseAlias))
        ]

    def listVariables(self, is_valid=None, types=None):
        if not isinstance(is_valid, (bool, type(None))):
            raise TypeError("Argument 'is_valid' must be type bool or NoneType")

        if not isinstance(types, (str, list, type(None))):
            raise TypeError("Argument 'types' must be type str, list, or NoneType")

        if types is None:
            return [
                symobj.name
                for symobj in self.getSymbols(self.listSymbols(is_valid))
                if isinstance(symobj, abcs.ABCVariable)
            ]

        else:
            if isinstance(types, str):
                types = [types]

            # casefold to allow mixed case matching
            types = [i.casefold() for i in types]

            if any(i not in VAR_STR_TO_TYPE.keys() for i in types):
                raise ValueError(
                    "User input unrecognized variable type, "
                    f"variable types can only take: {list(VAR_STR_TO_TYPE.keys())}"
                )

            return [
                symobj.name
                for symobj in self.getSymbols(self.listSymbols(is_valid))
                if isinstance(symobj, abcs.ABCVariable) and symobj.type in types
            ]

    def listEquations(self, is_valid=None, types=None):
        if not isinstance(is_valid, (bool, type(None))):
            raise TypeError("Argument 'is_valid' must be type bool or NoneType")

        if not isinstance(types, (str, list, type(None))):
            raise TypeError("Argument 'types' must be type str, list, or NoneType")

        if types is None:
            return [
                symobj.name
                for symobj in self.getSymbols(self.listSymbols(is_valid))
                if isinstance(symobj, abcs.ABCEquation)
            ]

        else:
            if isinstance(types, str):
                types = [types]

            # casefold to allow mixed case matching
            types = [i.casefold() for i in types]

            if any(i not in EQU_STR_TO_TYPE.keys() for i in types):
                raise ValueError(
                    "User input unrecognized variable type, "
                    f"variable types can only take: {list(VAR_STR_TO_TYPE.keys())}"
                )

            return [
                symobj.name
                for symobj in self.getSymbols(self.listSymbols(is_valid))
                if isinstance(symobj, abcs.ABCEquation) and symobj.type in types
            ]

    def read(self, load_from, symbols=None, records=True):
        if not isinstance(records, bool):
            raise TypeError("Argument 'records' must be type bool")

        if not isinstance(symbols, (list, str, type(None))):
            raise TypeError("Argument 'symbols' must be type str, list, or NoneType")

        if isinstance(symbols, str):
            symbols = [symbols]

        if symbols is not None:
            if any(not isinstance(i, str) for i in symbols):
                raise Exception("Argument 'symbols' must contain only type str")

        #
        # figure out data source type
        if isinstance(load_from, GamsDatabase):
            source = SourceType.GMD
            load_from = load_from._gmd

        elif isinstance(load_from, (os.PathLike, str)):
            fpath = pathlib.Path(load_from)

            if not fpath.expanduser().exists():
                raise Exception(
                    f"GDX file '{os.fspath(fpath.expanduser().resolve())}' does not exist, "
                    "check filename spelling or path specification"
                )

            if not os.fspath(fpath.expanduser().resolve()).endswith(".gdx"):
                raise Exception(
                    "Unexpected file type passed to 'load_from' argument "
                    "-- expected file extension '.gdx'"
                )

            source = SourceType.GDX
            load_from = os.fspath(fpath.expanduser().resolve())

        elif isinstance(load_from, abcs.ABCContainer):
            source = SourceType.CONTAINER

        else:
            # try GMD, if not, then mark as unknown
            try:
                ret = gmd.gmdInfo(load_from, gmd.GMD_NRSYMBOLSWITHALIAS)
                assert ret[0] == 1
                source = SourceType.GMD
            except:
                source = SourceType.UNKNOWN

        #
        # test for valid source
        if source is SourceType.UNKNOWN:
            raise TypeError(
                "Argument 'load_from' expects "
                "type str or PathLike (i.e., a path to a GDX file) "
                ", a valid gmdHandle (or GamsDatabase instance) "
                ", an instance of another Container "
                ", User passed: "
                f"'{type(load_from)}'."
            )

        #
        # read different types
        if source is SourceType.GDX:
            self._gdx_read(load_from, symbols, records)

        elif source is SourceType.GMD:
            self._gmd_read(load_from, symbols, records)

        elif source is SourceType.CONTAINER:
            self._container_constcontainer_read(load_from, symbols, records)

    def describeSets(self, symbols=None):
        if not isinstance(symbols, (str, list, type(None))):
            raise TypeError("Argument 'symbols' must be type str, list, or NoneType")

        if symbols is None:
            symbols = self.listSets()

        if isinstance(symbols, str):
            symbols = [symbols]

        if any(not isinstance(i, str) for i in symbols):
            raise TypeError("Argument 'symbols' must only contain type str")

        df = []
        cols = [
            "name",
            "is_singleton",
            "domain",
            "domain_type",
            "dim",
            "num_recs",
            "sparsity",
        ]

        # find all sets and aliases
        all_sets = self.listSets()
        all_aliases = self.listAliases()
        all_sets_aliases = all_sets + all_aliases

        for i in symbols:
            if i in all_sets_aliases:
                df.append(
                    pd.DataFrame(
                        data=[
                            [
                                i,
                                self[i].is_singleton,
                                self[i].domain_names,
                                self[i].domain_type,
                                self[i].dimension,
                                self[i].number_records,
                                self[i].getSparsity(),
                            ]
                        ],
                        columns=cols,
                    )
                )

        # concat list of dataframes
        if df != []:
            df = pd.concat(df, ignore_index=True).round(3)

            if any(i in all_aliases for i in symbols):
                df_is_alias = []
                df_alias_with = []

                for i in symbols:
                    if i in all_sets_aliases:
                        df_is_alias.append(
                            isinstance(self[i], (abcs.ABCAlias, abcs.ABCUniverseAlias))
                        )

                        if isinstance(self, abcs.ABCContainer):
                            if isinstance(self[i], abcs.ABCAlias):
                                df_alias_with.append(self[i].alias_with.name)
                            elif isinstance(self[i], abcs.ABCUniverseAlias):
                                df_alias_with.append(self[i].alias_with)
                            else:
                                df_alias_with.append(None)

                # add in is_alias column
                df.insert(2, "is_alias", df_is_alias)
                df.insert(3, "alias_with", df_alias_with)

            return df.sort_values(by="name", ignore_index=True)
        else:
            return None

    def describeAliases(self, symbols=None):
        if not isinstance(symbols, (str, list, type(None))):
            raise TypeError("Argument 'symbols' must be type str, list, or NoneType")

        if symbols is None:
            symbols = self.listAliases()

        if isinstance(symbols, str):
            symbols = [symbols]

        if any(not isinstance(i, str) for i in symbols):
            raise TypeError("Argument 'symbols' must only contain type str")

        df = []
        cols = [
            "name",
            "alias_with",
            "is_singleton",
            "domain",
            "domain_type",
            "dim",
            "num_recs",
            "sparsity",
        ]

        # find aliases
        all_aliases = self.listAliases()

        for i in symbols:
            if i in all_aliases:
                if isinstance(self, abcs.ABCContainer):
                    if isinstance(self[i], abcs.ABCAlias):
                        alias_name = self[i].alias_with.name
                    elif isinstance(self[i], abcs.ABCUniverseAlias):
                        alias_name = self[i].alias_with
                    else:
                        raise Exception("Encountered unknown symbol type")

                df.append(
                    pd.DataFrame(
                        data=[
                            [
                                i,
                                alias_name,
                                self[i].is_singleton,
                                self[i].domain_names,
                                self[i].domain_type,
                                self[i].dimension,
                                self[i].number_records,
                                self[i].getSparsity(),
                            ]
                        ],
                        columns=cols,
                    )
                )

        if df != []:
            return (
                pd.concat(df, ignore_index=True)
                .round(3)
                .sort_values(by="name", ignore_index=True)
            )
        else:
            return None

    def describeParameters(self, symbols=None):
        if not isinstance(symbols, (str, list, type(None))):
            raise TypeError("Argument 'symbols' must be type str, list, or NoneType")

        if symbols is None:
            symbols = self.listParameters()

        if isinstance(symbols, str):
            symbols = [symbols]

        if any(not isinstance(i, str) for i in symbols):
            raise TypeError("Argument 'symbols' must only contain type str")

        df = []
        cols = [
            "name",
            "is_scalar",
            "domain",
            "domain_type",
            "dim",
            "num_recs",
            "min_value",
            "mean_value",
            "max_value",
            "where_min",
            "where_max",
            "count_eps",
            "count_na",
            "count_undef",
            "sparsity",
        ]

        # find all parameters
        all_parameters = self.listParameters()

        for i in symbols:
            if i in all_parameters:
                df.append(
                    pd.DataFrame(
                        data=[
                            [
                                i,
                                self[i].is_scalar,
                                self[i].domain_names,
                                self[i].domain_type,
                                self[i].dimension,
                                self[i].number_records,
                                self[i].getMinValue(),
                                self[i].getMeanValue(),
                                self[i].getMaxValue(),
                                self[i].whereMin(),
                                self[i].whereMax(),
                                self[i].countEps(),
                                self[i].countNA(),
                                self[i].countUndef(),
                                self[i].getSparsity(),
                            ]
                        ],
                        columns=cols,
                    )
                )

        if df != []:
            return (
                pd.concat(df, ignore_index=True)
                .round(3)
                .sort_values(by="name", ignore_index=True)
            )
        else:
            return None

    def describeVariables(self, symbols=None):
        if not isinstance(symbols, (str, list, type(None))):
            raise TypeError("Argument 'symbols' must be type str, list, or NoneType")

        if symbols is None:
            symbols = self.listVariables()

        if isinstance(symbols, str):
            symbols = [symbols]

        if any(not isinstance(i, str) for i in symbols):
            raise TypeError("Argument 'symbols' must only contain type str")

        df = []
        cols = [
            "name",
            "type",
            "domain",
            "domain_type",
            "dim",
            "num_recs",
            "sparsity",
            "min_level",
            "mean_level",
            "max_level",
            "where_max_abs_level",
            "count_eps_level",
            "min_marginal",
            "mean_marginal",
            "max_marginal",
            "where_max_abs_marginal",
            "count_eps_marginal",
        ]

        # find all variables
        all_variables = self.listVariables()

        for i in symbols:
            if i in all_variables:
                df.append(
                    pd.DataFrame(
                        data=[
                            [
                                i,
                                self[i].type,
                                self[i].domain_names,
                                self[i].domain_type,
                                self[i].dimension,
                                self[i].number_records,
                                self[i].getSparsity(),
                                self[i].getMinValue("level"),
                                self[i].getMeanValue("level"),
                                self[i].getMaxValue("level"),
                                self[i].whereMaxAbs("level"),
                                self[i].countEps("level"),
                                self[i].getMinValue("marginal"),
                                self[i].getMeanValue("marginal"),
                                self[i].getMaxValue("marginal"),
                                self[i].whereMaxAbs("marginal"),
                                self[i].countEps("marginal"),
                            ]
                        ],
                        columns=cols,
                    )
                )

        if df != []:
            return (
                pd.concat(df, ignore_index=True)
                .round(3)
                .sort_values(by="name", ignore_index=True)
            )
        else:
            return None

    def describeEquations(self, symbols=None):
        if not isinstance(symbols, (str, list, type(None))):
            raise TypeError("Argument 'symbols' must be type str, list, or NoneType")

        if symbols is None:
            symbols = self.listEquations()

        if isinstance(symbols, str):
            symbols = [symbols]

        if any(not isinstance(i, str) for i in symbols):
            raise TypeError("Argument 'symbols' must only contain type str")

        df = []
        cols = [
            "name",
            "type",
            "domain",
            "domain_type",
            "dim",
            "num_recs",
            "sparsity",
            "min_level",
            "mean_level",
            "max_level",
            "where_max_abs_level",
            "count_eps_level",
            "min_marginal",
            "mean_marginal",
            "max_marginal",
            "where_max_abs_marginal",
            "count_eps_marginal",
        ]

        # find all equations
        all_equations = self.listEquations()

        for i in symbols:
            if i in all_equations:
                df.append(
                    pd.DataFrame(
                        data=[
                            [
                                i,
                                self[i].type,
                                self[i].domain_names,
                                self[i].domain_type,
                                self[i].dimension,
                                self[i].number_records,
                                self[i].getSparsity(),
                                self[i].getMinValue("level"),
                                self[i].getMeanValue("level"),
                                self[i].getMaxValue("level"),
                                self[i].whereMaxAbs("level"),
                                self[i].countEps("level"),
                                self[i].getMinValue("marginal"),
                                self[i].getMeanValue("marginal"),
                                self[i].getMaxValue("marginal"),
                                self[i].whereMaxAbs("marginal"),
                                self[i].countEps("marginal"),
                            ]
                        ],
                        columns=cols,
                    )
                )

        if df != []:
            return (
                pd.concat(df, ignore_index=True)
                .round(3)
                .sort_values(by="name", ignore_index=True)
            )
        else:
            return None

    def getSymbols(self, symbols):
        if isinstance(symbols, str):
            symbols = [symbols]

        if not isinstance(symbols, Iterable):
            raise ValueError("Argument 'symbols' must be type str or other iterable")

        obj = []
        for symname in symbols:
            try:
                obj.append(self[symname])
            except KeyError as err:
                raise KeyError(f"Symbol `{symname}` does not appear in the Container")
        return obj
