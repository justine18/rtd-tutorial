#
# GAMS - General Algebraic Modeling System Python API
#
# Copyright (c) 2017-2023 GAMS Development Corp. <support@gams.com>
# Copyright (c) 2017-2023 GAMS Software GmbH <support@gams.com>
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
#

from gams.transfer._abcs import ABCSet, ABCEquation
from gams.transfer.syms._mixins import (
    PVEMixin,
    SAPVEMixin,
    SAUAPVEMixin,
    SPVEMixin,
    VEMixin,
)
from gams.transfer._internals import (
    GamsSymbolTuple,
    EQU_DEFAULT_VALUES,
    TRANSFER_TYPE,
    EQU_STR_TO_TYPE,
)
from gams.transfer.syms._mixins.pivot import PivotEquationMixin
from gams.transfer.syms._mixins.generateRecords import GenerateRecordsEquationMixin
from gams.transfer.syms._mixins.equals import EqualsEquationMixin
from typing import Any, List, Optional, Union, TYPE_CHECKING

if TYPE_CHECKING:
    from gams.transfer import Container


class Equation(
    PVEMixin,
    SAPVEMixin,
    SAUAPVEMixin,
    SPVEMixin,
    VEMixin,
    PivotEquationMixin,
    GenerateRecordsEquationMixin,
    EqualsEquationMixin,
    ABCEquation,
):
    def __init__(
        self,
        container: "Container",
        name: str,
        type: str,
        domain: Optional[List[Union[ABCSet, str]]] = None,
        records: Optional[Any] = None,
        domain_forwarding: bool = False,
        description: str = "",
        uels_on_axes: bool = False,
    ):
        """Equation symbol

        Parameters
        ----------
        container : Container
        name : str
        type : str
        domain : Union[Set, str], optional
        records : Any, optional
        domain_forwarding : bool, optional
        description : str, optional
        uels_on_axes: bool
        definition: Expression, optional
        definition_domain: list, optional

        Example
        ----------
        >>> m = gt.Container()
        >>> i = gt.Set(m, "i", records=['i1','i2'])
        >>> a = gt.Parameter(m, "a", [i], records=[['i1',1],['i2',2]])
        >>> e = gt.Equation(m, "e", [i])
        >>> e[i] = Sum(i, a[i]) == a
        """
        # domain handling
        if domain is None:
            domain = []

        if isinstance(domain, (ABCSet, str)):
            domain = [domain]

        # main setup
        self.type = type
        self._gams_type, self._gams_subtype = GamsSymbolTuple[
            self._type.name
        ].value  # type: tuple[int, int]
        self._requires_state_check = True
        self.ref_container = container
        self.ref_container._requires_state_check = True
        self.name = name
        self.domain = domain
        self.domain_forwarding = domain_forwarding
        self.description = description
        self.records = None
        self.modified = True

        # add to ref_container
        self.ref_container.data.update({name: self})

        # only set records if records are provided
        if records is not None:
            self.setRecords(records, uels_on_axes=uels_on_axes)

    def __repr__(self):
        return f"<{self.type.capitalize()} Equation `{self.name}` ({hex(id(self))})>"

    def __delitem__(self):
        del self.ref_container.data[self.name]

    @property
    def _default_values(self):
        return EQU_DEFAULT_VALUES[self._type]

    @property
    def type(self):
        return TRANSFER_TYPE[self._type]

    @type.setter
    def type(self, typ):
        typ = typ.casefold()

        if typ not in EQU_STR_TO_TYPE.keys():
            raise ValueError(
                "Argument 'type' must be one of the following (mixed-case OK): \n\n"
                "1. 'eq', 'E', or '=E=' -- equality \n"
                "2. 'geq', 'G', or '=G=' -- greater than or equal to inequality \n"
                "3. 'leq', 'L', or '=L=''  -- less than or equal to inequality \n"
                "4. 'nonbinding', 'N', or '=N='  -- nonbinding relationship \n"
                "5. 'cone', 'C', or '=C=' -- cone equation \n"
                "6. 'external', 'X', or '=X=' -- external equation \n"
                "7. 'boolean', 'B', or '=B=' -- boolean equation \n\n"
                f"User passed: `{typ}`"
            )

        # check to see if _symbol_type is being changed
        if getattr(self, "type", None) is not None:
            if self._type is not EQU_STR_TO_TYPE[typ]:
                self._requires_state_check = True

                self.ref_container._requires_state_check = True
                self.ref_container.modified = True

                # set the symbol type
                self._type = EQU_STR_TO_TYPE[typ]
                self.modified = True
        else:
            # set the symbol type
            self._type = EQU_STR_TO_TYPE[typ]
            self.modified = True
