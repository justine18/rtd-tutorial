#
# GAMS - General Algebraic Modeling System Python API
#
# Copyright (c) 2017-2023 GAMS Development Corp. <support@gams.com>
# Copyright (c) 2017-2023 GAMS Software GmbH <support@gams.com>
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
#

import weakref
import gams.transfer._abcs as abcs
from gams.transfer._internals import CasePreservingDict, GAMS_SYMBOL_MAX_LENGTH


class SAUAPVEMixin:
    @property
    def modified(self):
        return self._modified

    @modified.setter
    def modified(self, modified):
        if not isinstance(modified, bool):
            raise TypeError("Attribute 'modified' must be type bool")

        self._modified = modified

    @property
    def ref_container(self):
        return self._ref_container

    @ref_container.setter
    def ref_container(self, container):
        if not isinstance(container, abcs.ABCContainer):
            raise TypeError("Symbol 'container' must be type Container")

        # create a weak proxy to help garbage collection
        container = weakref.proxy(container)

        # if old_container != new_container
        if getattr(self, "ref_container", None) is not None:
            if self.ref_container != container:
                # reset check flags for old container
                self.ref_container._requires_state_check = True
                self.ref_container.modified = True

        # set new container
        self._ref_container = container

        # set check flags for new container
        self.ref_container._requires_state_check = True
        self.ref_container.modified = True

        # set check flags for symbol
        self._requires_state_check = True
        self.modified = True

    def isValid(self, verbose=False, force=False):
        if not isinstance(verbose, bool):
            raise ValueError("Argument 'verbose' must be type bool")

        if not isinstance(force, bool):
            raise ValueError("Argument 'force' must be type bool")

        if force:
            self._requires_state_check = True

        if self._requires_state_check:
            try:
                self._assert_is_valid()
                return True
            except Exception as err:
                if verbose:
                    raise err
                return False
        else:
            return True

    @property
    def name(self):
        return self._name

    @name.setter
    def name(self, name):
        if not isinstance(name, str):
            raise TypeError("Symbol 'name' must be type str")

        if not len(name) <= GAMS_SYMBOL_MAX_LENGTH:
            raise ValueError(
                "GAMS symbol 'name' is too long, "
                f"max is {GAMS_SYMBOL_MAX_LENGTH} characters"
            )

        if name[0] == "_":
            raise Exception("Valid GAMS names cannot being with a '_' character.")

        if not all(True if i == "_" else i.isalnum() for i in name):
            raise Exception(
                "Detected an invalid GAMS symbol name. "
                "GAMS names can only contain alphanumeric characters "
                "(letters and numbers) and the '_' character."
            )

        if name in self.ref_container:
            raise ValueError(
                f"Attempting to add a symbol named `{name}` "
                "but one already exists in the Container. "
                "Symbol replacement is only possible if the symbol is "
                "first removed from the Container with the removeSymbols() method."
            )

        if getattr(self, "name", None) is not None:
            if self.name != name:
                self._requires_state_check = True

                if isinstance(self.ref_container, abcs.ABCContainer):
                    if name in self.ref_container:
                        raise Exception(
                            f"Attempting rename symbol `{self.name}` to `{name}` "
                            "but a symbol with this name already exists in the Container. "
                            "All symbols in a single Container instance must have unique names. "
                            "The user can remedy this issue by "
                            "1) removing the original symbol from the Container with the removeSymbols() method, or "
                            "2) creating separate Container instances. "
                        )

                    self.ref_container.data = CasePreservingDict(
                        {
                            name if k == self.name else k: v
                            for k, v in self.ref_container
                        }
                    )
                    self.ref_container._requires_state_check = True
                    self.ref_container.modified = True

                    # set the name
                    self._name = name
                    self.modified = True

                    # update any records column headings
                    for symname, symobj in self.ref_container:
                        if symobj.records is not None and name in symobj.domain_names:
                            symobj.modified = True

        else:
            # set the name
            self._name = name
            self.modified = True
