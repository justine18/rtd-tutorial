#
# GAMS - General Algebraic Modeling System Python API
#
# Copyright (c) 2017-2023 GAMS Development Corp. <support@gams.com>
# Copyright (c) 2017-2023 GAMS Software GmbH <support@gams.com>
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
#

import itertools
import random
import numpy as np


def generate_unique_labels(labels):
    if not isinstance(labels, list):
        labels = [labels]

    # default domain labels
    labels = [i if i != "*" else "uni" for i in labels]

    # make unique
    is_unique = False
    if len(labels) == len(set(labels)):
        is_unique = True

    if not is_unique:
        labels = [f"{i}_{n}" for n, i in enumerate(labels)]

    return labels


def cartesian_product(*arrays):
    la = len(arrays)
    dtype = np.result_type(*arrays)
    arr = np.empty((la, *map(len, arrays)), dtype=dtype)
    idx = slice(None), *itertools.repeat(None, la)
    for i, a in enumerate(arrays):
        arr[i, ...] = a[idx[: la - i]]
    return arr.reshape(la, -1).T


def choice_no_replace(choose_from, n_choose, seed=None):
    if not isinstance(seed, (int, type(None))):
        raise TypeError("Argument 'seed' must be type int or NoneType")

    if not isinstance(choose_from, int):
        choose_from = int(choose_from)

    if not isinstance(n_choose, int):
        n_choose = int(n_choose)

    density = n_choose / choose_from

    try:
        if density == 1:
            return np.arange(choose_from, dtype=int)

        # numpy is faster as density grows
        if 0.08 < density < 1:
            rng = np.random.default_rng(seed)
            idx = rng.choice(
                np.arange(choose_from, dtype=int), replace=False, size=(n_choose,)
            )

        # random.shuffle is much much faster at low density
        elif density <= 0.08:
            random.seed(seed)
            idx = np.array(random.sample(range(choose_from), n_choose), dtype=int)
        else:
            raise Exception(
                "Argument 'density' is our of bounds, must be on the interval [0,1]."
            )

        return np.sort(idx)

    except Exception as err:
        raise err
