#
# GAMS - General Algebraic Modeling System Python API
#
# Copyright (c) 2017-2023 GAMS Development Corp. <support@gams.com>
# Copyright (c) 2017-2023 GAMS Software GmbH <support@gams.com>
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
#

import itertools
from enum import auto, Enum, Flag
from gams.core.gdx import GMS_UEL_IDENT_SIZE, GMS_SSSIZE, GMS_MAX_INDEX_DIM
from gams.core.gdx import GMS_DT_SET, GMS_DT_ALIAS, GMS_DT_PAR, GMS_DT_VAR, GMS_DT_EQU
from gams.core.gdx import (
    GMS_VARTYPE_FREE,
    GMS_VARTYPE_BINARY,
    GMS_VARTYPE_INTEGER,
    GMS_VARTYPE_NEGATIVE,
    GMS_VARTYPE_POSITIVE,
    GMS_VARTYPE_SEMICONT,
    GMS_VARTYPE_SEMIINT,
    GMS_VARTYPE_SOS1,
    GMS_VARTYPE_SOS2,
)
from gams.core.gdx import (
    GMS_EQUTYPE_B,
    GMS_EQUTYPE_C,
    GMS_EQUTYPE_E,
    GMS_EQUTYPE_G,
    GMS_EQUTYPE_L,
    GMS_EQUTYPE_N,
    GMS_EQUTYPE_X,
)
from gams.transfer._internals import SpecialValues

GAMS_SYMBOL_MAX_LENGTH = GMS_UEL_IDENT_SIZE - 1
GAMS_UEL_MAX_LENGTH = GMS_UEL_IDENT_SIZE - 1
GAMS_DESCRIPTION_MAX_LENGTH = GMS_SSSIZE - 1
GAMS_MAX_INDEX_DIM = GMS_MAX_INDEX_DIM


class DictFormat(Enum):
    UNKNOWN = -1
    COLUMNS = 0
    NATURAL = 1

    @classmethod
    def _missing_(cls, value):
        return DictFormat.UNKNOWN


DICT_FORMAT = {
    "natural": DictFormat.NATURAL,
    "columns": DictFormat.COLUMNS,
}


class SourceType(Enum):
    UNKNOWN = -1
    GDX = 0
    GMD = 1
    CONTAINER = 2

    @classmethod
    def _missing_(cls, value):
        return SourceType.UNKNOWN


class DestinationType(Enum):
    UNKNOWN = -1
    GDX = 0
    GMD = 1

    @classmethod
    def _missing_(cls, value):
        return DestinationType.UNKNOWN


class GamsSymbol(Flag):
    UNKNOWN = auto()
    SET = auto()
    PARAMETER = auto()
    SINGLETON_SET = auto()
    BINARY_VARIABLE = auto()
    INTEGER_VARIABLE = auto()
    POSITIVE_VARIABLE = auto()
    NEGATIVE_VARIABLE = auto()
    FREE_VARIABLE = auto()
    SOS1_VARIABLE = auto()
    SOS2_VARIABLE = auto()
    SEMICONT_VARIABLE = auto()
    SEMIINT_VARIABLE = auto()
    EQ_EQUATION = auto()
    GEQ_EQUATION = auto()
    LEQ_EQUATION = auto()
    NONBINDING_EQUATION = auto()
    EXTERNAL_EQUATION = auto()
    CONE_EQUATION = auto()
    BOOLEAN_EQUATION = auto()
    ALIAS = auto()
    UNIVERSE_ALIAS = auto()
    VARIABLE = (
        BINARY_VARIABLE
        | INTEGER_VARIABLE
        | POSITIVE_VARIABLE
        | NEGATIVE_VARIABLE
        | FREE_VARIABLE
        | SOS1_VARIABLE
        | SOS2_VARIABLE
        | SEMICONT_VARIABLE
        | SEMIINT_VARIABLE
    )
    EQUATION = (
        EQ_EQUATION
        | GEQ_EQUATION
        | LEQ_EQUATION
        | NONBINDING_EQUATION
        | EXTERNAL_EQUATION
        | CONE_EQUATION
        | BOOLEAN_EQUATION
    )

    @classmethod
    def _missing_(cls, value):
        return GamsSymbol.UNKNOWN


class DomainStatus(Enum):
    UNKNOWN = 0
    none = 1
    relaxed = 2
    regular = 3

    @classmethod
    def _missing_(cls, value):
        return DomainStatus.UNKNOWN


class GamsSymbolTuple(Enum):
    UNKNOWN = (-1, -1)
    SET = (GMS_DT_SET, 0)
    PARAMETER = (GMS_DT_PAR, 0)
    SINGLETON_SET = (GMS_DT_SET, 1)
    BINARY_VARIABLE = (GMS_DT_VAR, GMS_VARTYPE_BINARY)
    INTEGER_VARIABLE = (GMS_DT_VAR, GMS_VARTYPE_INTEGER)
    POSITIVE_VARIABLE = (GMS_DT_VAR, GMS_VARTYPE_POSITIVE)
    NEGATIVE_VARIABLE = (GMS_DT_VAR, GMS_VARTYPE_NEGATIVE)
    FREE_VARIABLE = (GMS_DT_VAR, GMS_VARTYPE_FREE)
    SOS1_VARIABLE = (GMS_DT_VAR, GMS_VARTYPE_SOS1)
    SOS2_VARIABLE = (GMS_DT_VAR, GMS_VARTYPE_SOS2)
    SEMICONT_VARIABLE = (GMS_DT_VAR, GMS_VARTYPE_SEMICONT)
    SEMIINT_VARIABLE = (GMS_DT_VAR, GMS_VARTYPE_SEMIINT)
    EQ_EQUATION = (GMS_DT_EQU, GMS_EQUTYPE_E)
    GEQ_EQUATION = (GMS_DT_EQU, GMS_EQUTYPE_G)
    LEQ_EQUATION = (GMS_DT_EQU, GMS_EQUTYPE_L)
    NONBINDING_EQUATION = (GMS_DT_EQU, GMS_EQUTYPE_N)
    EXTERNAL_EQUATION = (GMS_DT_EQU, GMS_EQUTYPE_X)
    CONE_EQUATION = (GMS_DT_EQU, GMS_EQUTYPE_C)
    BOOLEAN_EQUATION = (GMS_DT_EQU, GMS_EQUTYPE_B)
    ALIAS = (GMS_DT_ALIAS, 1)
    UNIVERSE_ALIAS = (GMS_DT_ALIAS, 0)

    @classmethod
    def _missing_(cls, value):
        if value[0] == 2:
            return GamsSymbolTuple.FREE_VARIABLE
        elif value[0] == 3:
            return GamsSymbolTuple.EQ_EQUATION
        elif value[0] == 4:
            return GamsSymbolTuple.ALIAS
        else:
            return GamsSymbolTuple.UNKNOWN


TRANSFER_TYPE = {
    GamsSymbol.BINARY_VARIABLE: "binary",
    GamsSymbol.INTEGER_VARIABLE: "integer",
    GamsSymbol.POSITIVE_VARIABLE: "positive",
    GamsSymbol.NEGATIVE_VARIABLE: "negative",
    GamsSymbol.FREE_VARIABLE: "free",
    GamsSymbol.SOS1_VARIABLE: "sos1",
    GamsSymbol.SOS2_VARIABLE: "sos2",
    GamsSymbol.SEMICONT_VARIABLE: "semicont",
    GamsSymbol.SEMIINT_VARIABLE: "semiint",
    GamsSymbol.EQ_EQUATION: "eq",
    GamsSymbol.GEQ_EQUATION: "geq",
    GamsSymbol.LEQ_EQUATION: "leq",
    GamsSymbol.NONBINDING_EQUATION: "nonbinding",
    GamsSymbol.EXTERNAL_EQUATION: "external",
    GamsSymbol.CONE_EQUATION: "cone",
    GamsSymbol.BOOLEAN_EQUATION: "boolean",
}


VAR_STR_TO_TYPE = {
    strname: typ for typ, strname in TRANSFER_TYPE.items() if typ in GamsSymbol.VARIABLE
}


VAR_DEFAULT_VALUES = {
    GamsSymbol.BINARY_VARIABLE: {
        "level": 0.0,
        "marginal": 0.0,
        "lower": 0.0,
        "upper": 1.0,
        "scale": 1.0,
    },
    GamsSymbol.INTEGER_VARIABLE: {
        "level": 0.0,
        "marginal": 0.0,
        "lower": 0.0,
        "upper": SpecialValues.POSINF,
        "scale": 1.0,
    },
    GamsSymbol.POSITIVE_VARIABLE: {
        "level": 0.0,
        "marginal": 0.0,
        "lower": 0.0,
        "upper": SpecialValues.POSINF,
        "scale": 1.0,
    },
    GamsSymbol.NEGATIVE_VARIABLE: {
        "level": 0.0,
        "marginal": 0.0,
        "lower": SpecialValues.NEGINF,
        "upper": 0.0,
        "scale": 1.0,
    },
    GamsSymbol.FREE_VARIABLE: {
        "level": 0.0,
        "marginal": 0.0,
        "lower": SpecialValues.NEGINF,
        "upper": SpecialValues.POSINF,
        "scale": 1.0,
    },
    GamsSymbol.SOS1_VARIABLE: {
        "level": 0.0,
        "marginal": 0.0,
        "lower": 0.0,
        "upper": SpecialValues.POSINF,
        "scale": 1.0,
    },
    GamsSymbol.SOS2_VARIABLE: {
        "level": 0.0,
        "marginal": 0.0,
        "lower": 0.0,
        "upper": SpecialValues.POSINF,
        "scale": 1.0,
    },
    GamsSymbol.SEMICONT_VARIABLE: {
        "level": 0.0,
        "marginal": 0.0,
        "lower": 1.0,
        "upper": SpecialValues.POSINF,
        "scale": 1.0,
    },
    GamsSymbol.SEMIINT_VARIABLE: {
        "level": 0.0,
        "marginal": 0.0,
        "lower": 1.0,
        "upper": SpecialValues.POSINF,
        "scale": 1.0,
    },
}

# equation types
EQU_STR_TO_TYPE = {
    strname: typ for typ, strname in TRANSFER_TYPE.items() if typ in GamsSymbol.EQUATION
}

# additional user supported notation for defining equation types
EQU_STR_TO_TYPE.update(
    {
        "=e=": GamsSymbol.EQ_EQUATION,
        "e": GamsSymbol.EQ_EQUATION,
    }
)

EQU_STR_TO_TYPE.update(
    {
        "=g=": GamsSymbol.GEQ_EQUATION,
        "g": GamsSymbol.GEQ_EQUATION,
    }
)

EQU_STR_TO_TYPE.update(
    {
        "=l=": GamsSymbol.LEQ_EQUATION,
        "l": GamsSymbol.LEQ_EQUATION,
    }
)

EQU_STR_TO_TYPE.update(
    {
        "=n=": GamsSymbol.NONBINDING_EQUATION,
        "n": GamsSymbol.NONBINDING_EQUATION,
    }
)

EQU_STR_TO_TYPE.update(
    {
        "=x=": GamsSymbol.EXTERNAL_EQUATION,
        "x": GamsSymbol.EXTERNAL_EQUATION,
    }
)

EQU_STR_TO_TYPE.update(
    {
        "=c=": GamsSymbol.CONE_EQUATION,
        "c": GamsSymbol.CONE_EQUATION,
    }
)

EQU_STR_TO_TYPE.update(
    {
        "=b=": GamsSymbol.BOOLEAN_EQUATION,
        "b": GamsSymbol.BOOLEAN_EQUATION,
    }
)

EQU_DEFAULT_VALUES = {
    GamsSymbol.EQ_EQUATION: {
        "level": 0.0,
        "marginal": 0.0,
        "lower": 0.0,
        "upper": 0.0,
        "scale": 1.0,
    },
    GamsSymbol.GEQ_EQUATION: {
        "level": 0.0,
        "marginal": 0.0,
        "lower": 0.0,
        "upper": SpecialValues.POSINF,
        "scale": 1.0,
    },
    GamsSymbol.LEQ_EQUATION: {
        "level": 0.0,
        "marginal": 0.0,
        "lower": SpecialValues.NEGINF,
        "upper": 0.0,
        "scale": 1.0,
    },
    GamsSymbol.NONBINDING_EQUATION: {
        "level": 0.0,
        "marginal": 0.0,
        "lower": SpecialValues.NEGINF,
        "upper": SpecialValues.POSINF,
        "scale": 1.0,
    },
    GamsSymbol.CONE_EQUATION: {
        "level": 0.0,
        "marginal": 0.0,
        "lower": 0.0,
        "upper": SpecialValues.POSINF,
        "scale": 1.0,
    },
    GamsSymbol.EXTERNAL_EQUATION: {
        "level": 0.0,
        "marginal": 0.0,
        "lower": 0.0,
        "upper": 0.0,
        "scale": 1.0,
    },
    GamsSymbol.BOOLEAN_EQUATION: {
        "level": 0.0,
        "marginal": 0.0,
        "lower": 0.0,
        "upper": 0.0,
        "scale": 1.0,
    },
}


# equivalents
EPS = set(list(map("".join, itertools.product(*zip("EPS", "eps")))))
UNDEF = set(list(map("".join, itertools.product(*zip("UNDEF", "undef")))))
NA = set(list(map("".join, itertools.product(*zip("NA", "na")))))
