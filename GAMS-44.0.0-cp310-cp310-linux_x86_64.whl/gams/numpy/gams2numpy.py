#
# GAMS - General Algebraic Modeling System Python API
#
# Copyright (c) 2017-2023 GAMS Development Corp. <support@gams.com>
# Copyright (c) 2017-2023 GAMS Software GmbH <support@gams.com>
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
#

from gams.numpy import _gams2numpy
from gams.core.gdx import *
from gams.core.gmd import *
from gams.control.database import GamsDatabase, _GamsSymbol
from gams.control.workspace import GamsWorkspace

class Gams2Numpy(object):
    def __init__(self, system_directory=None):
        if system_directory:
            ws = GamsWorkspace(system_directory = system_directory)
        else:
            ws = GamsWorkspace()
        self._system_directory = ws.system_directory
        _gams2numpy.getReady(self._system_directory)
    
    def _get_system_directory(self):
        return self._system_directory
    ## @brief GAMS system directory
    system_directory = property(_get_system_directory)
    
    def _validateArray(self, arr, symDim, symType):
        if len(arr.shape) != 2:
            raise Exception("Numpy array needs to have exactly two dimensions")
        expectedCols = symDim
        if symType in [GMS_DT_PAR, GMS_DT_SET, GMS_DT_ALIAS]:
           expectedCols += 1
        elif symType in [GMS_DT_VAR, GMS_DT_EQU]:
           expectedCols +=5

        if arr.shape[1] != expectedCols:
           if symType in [GMS_DT_SET, GMS_DT_ALIAS] and arr.shape[1] == expectedCols-1: #for sets we allow to skip the explanatory text
               pass
           else:
               raise Exception("Unexpected number of columns")

    def _convertTypes(self, arr, symType, dim, raw):
        arr2 = arr.astype(object)
        if raw:
            arr2[:, :dim] = arr2[:, :dim].astype(int)
        else:
            arr2[:, :dim] = arr2[:, :dim].astype(str)
        if symType in [GMS_DT_SET, GMS_DT_ALIAS]:
            arr2[:, dim:] = arr2[:, dim:].astype(str)
        else:
            arr2[:, dim:] = arr2[:, dim:].astype(float)
        return arr2
    
    def gdxGetUelList(self, gdx, encoding=None):
        '''
        @brief Retrieve the list of UELs.
        @param gdx GDX handle created with 'gdxcc.new_gdxHandle_tp' or GDX file name.
        @param encoding The name of the encoding, default None means utf-8.
        @return List of UELs.
        '''
        if isinstance(gdx, str): # treat parameter 'gdx' as file name
            gdxHandle = new_gdxHandle_tp()
            rc, msg = gdxCreateD(gdxHandle, self._system_directory, GMS_SSSIZE)
            if not rc:
                raise Exception(msg)
            if not gdxOpenRead(gdxHandle, gdx)[0]:
                raise Exception("Error opening GDX file "+gdx)
            ret = _gams2numpy.gdxGetUelList(gdxHandleToPtr(gdxHandle), encoding)
            gdxClose(gdxHandle)
            gdxFree(gdxHandle)
            return ret
        else: # treat parameter 'gdx' as GDX handle
            return _gams2numpy.gdxGetUelList(gdxHandleToPtr(gdx), encoding)


    def gmdGetUelList(self, gmd, encoding=None):
        '''
        @brief Retrieve the list of UELs.
        @param gmd GMD handle created with 'gmdcc.new_gmdHandle_tp' or an instance of GamsDatabase.
        @param encoding The name of the encoding, default None means utf-8.
        @return List of UELs.
        '''
        if isinstance(gmd, GamsDatabase):
            gmdH = gmd._gmd
        else:
            gmdH = gmd
        return _gams2numpy.gmdGetUelList(gmdHandleToPtr(gmdH), encoding)


    def _gdxReadSymbol(self, gdx, symName, raw, uelList=None, encoding=None):
        if isinstance(gdx, str): # treat parameter 'gdx' as file name
            gdxHandle = new_gdxHandle_tp()
            rc, msg = gdxCreateD(gdxHandle, self._system_directory, GMS_SSSIZE)
            if not rc:
                raise Exception(msg)
            if not gdxOpenRead(gdxHandle, gdx)[0]:
                raise Exception("Error opening GDX file "+gdx)
            ret = _gams2numpy.gdxReadSymbol(gdxHandleToPtr(gdxHandle), symName, raw, uelList, encoding)
            gdxClose(gdxHandle)
            gdxFree(gdxHandle)
            return ret
        else: # treat parameter 'gdx' as GDX handle
            return _gams2numpy.gdxReadSymbol(gdxHandleToPtr(gdx), symName, raw, uelList, encoding)
    
    
    def gdxReadSymbolStr(self, gdx, symName, uelList=None, encoding=None):
        '''
        @brief Reads symbol data from GDX into a numpy array using strings for keys.
        @param gdx GDX handle created with 'gdxcc.new_gdxHandle_tp' or GDX file name.
        @param symName The name of the symbol to be read.
        @param uelList List of UELs to be used for mapping internal numbers to labels, usually retrieved by 'gdxGetUelList'. If omitted, the UEL list is generated internally from the GDX file.
               Supplying this parameter can increase performance when reading multiple symbols from the same GDX file since the UEL list creation has to be performed only once.
        @param encoding The name of the encoding, default None means utf-8.
        @return Two dimensional numpy array representing the data from the symbol with keys represented as strings.
        '''
        return self._gdxReadSymbol(gdx, symName, False, uelList, encoding)
    
    
    def gdxReadSymbolRaw(self, gdx, symName, encoding=None):
        '''
        @brief Reads symbol data from GDX into a numpy array using integers for keys.
        @param gdx GDX handle created with 'gdxcc.new_gdxHandle_tp' or GDX file name.
        @param symName The name of the symbol to be read.
        @param encoding The name of the encoding, default None means utf-8.
        @return Two dimensional numpy array representing the data from the symbol with keys represented as integers.
        '''
        return self._gdxReadSymbol(gdx, symName, True, encoding)
    
    
    def _gdxWriteSymbol(self, gdx, symName, explText, dim, symType, subType, arr, raw, domains, relaxedType):
        self._validateArray(arr, dim, symType)
        if relaxedType:
            arr = self._convertTypes(arr, symType, dim, raw)

        if domains != None:
            if not isinstance(domains, list):
                raise Exception("Parameter domains has to be of type list, but is " + str(type(domains)))
            if len(domains) != dim:
                raise Exception("Length of domains(" + str(len(domains)) + ") does not match parameter dim(" + str(dim) + ")")
    
        if isinstance(gdx, str):
            gdxHandle = new_gdxHandle_tp()
            rc, msg = gdxCreateD(gdxHandle, self._system_directory, GMS_SSSIZE)
            if not rc:
                raise Exception(msg)
            if not gdxOpenWrite(gdxHandle, gdx, "")[0]:
                raise Exception("Error opening GDX file "+gdx)
            ret = _gams2numpy.gdxWriteSymbol(gdxHandleToPtr(gdxHandle), symName, explText, dim, symType, subType, arr, raw, domains)
            gdxClose(gdxHandle)
            gdxFree(gdxHandle)
            return ret
        return _gams2numpy.gdxWriteSymbol(gdxHandleToPtr(gdx), symName, explText, dim, symType, subType, arr, raw, domains)
    
    
    def gdxWriteSymbolStr(self, gdx, symName, explText, dim, symType, subType, arr, domains=None, relaxedType=False):
        '''
        @brief Creates a GDX symbol and fills it with the data from the provided numpy array.
        @param gdx GDX handle created with 'gdxcc.new_gdxHandle_tp' or GDX file name.
        @param symName The name of the symbol to be created.
        @param explText Explanatory text.
        @param dim The dimension of the symbol.
        @param symType The type of the symbol.
        @param subType The sybType of the symbol.
        @param arr Two dimensional numpy array containing strings for keys.
        @param domains List of domains (str) to be used for the symbol (optional).
        @param relaxedType Automatically convert the columns of the numpy array into the required data types if possible (default: False).
        @return None
        '''
        return self._gdxWriteSymbol(gdx, symName, explText, dim, symType, subType, arr, False, domains, relaxedType)
    
    
    def gdxWriteSymbolRaw(self, gdx, symName, explText, dim, symType, subType, arr, domains=None, relaxedType=False):
        '''
        @brief Creates a GDX symbol and fills it with the data from the provided numpy array.
        @param gdx GDX handle created with 'gdxcc.new_gdxHandle_tp' or GDX file name.
        @param symName The name of the symbol to be created.
        @param explText Explanatory text.
        @param dim The dimension of the symbol.
        @param symType The type of the symbol.
        @param subType The sybType of the symbol.
        @param arr Two dimensional numpy array containing integers for keys.
        @param domains List of domains (str) to be used for the symbol (optional).
        @param relaxedType Automatically convert the columns of the numpy array into the required data types if possible (default: False).
        @return None
        '''
        return self._gdxWriteSymbol(gdx, symName, explText, dim, symType, subType, arr, True, domains, relaxedType)
    
    def _gmdReadSymbol(self, gmd, symName, raw, uelList=None, encoding=None):
        if isinstance(gmd, GamsDatabase):
            gmdH = gmd._gmd
        else:
            gmdH = gmd
        return _gams2numpy.gmdReadSymbol(gmdHandleToPtr(gmdH), symName, raw, uelList, encoding)
    
    
    def gmdReadSymbolStr(self, gmd, symName, uelList=None, encoding=None):
        '''
        @brief Reads symbol data from GMD into a numpy array using strings for keys.
        @param gmd GMD handle created with 'gmdcc.new_gmdHandle_tp' or an instance of GamsDatabase.
        @param symName The name of the symbol to be read.
        @param uelList List of UELs to be used for mapping internal numbers to labels, usually retrieved by 'gmdGetUelList'. If omitted, the UEL list is generated internally from the GMD handle.
               Supplying this parameter can increase performance when reading multiple symbols from the same GMD handle since the UEL list creation has to be performed only once.
        @param encoding The name of the encoding, default None means utf-8.
        @return Two dimensional numpy array representing the data from the symbol with keys represented as strings.
        '''
        return self._gmdReadSymbol(gmd, symName, False, uelList, encoding)
    
    
    def gmdReadSymbolRaw(self, gmd, symName, encoding=None):
        '''
        @brief Reads symbol data from GMD into a numpy array using strings for keys.
        @param gmd GMD handle created with 'gmdcc.new_gmdHandle_tp' or an instance of GamsDatabase.
        @param symName The name of the symbol to be read.
        @param encoding The name of the encoding, default None means utf-8.
        @return Two dimensional numpy array representing the data from the symbol withkeys represented as integers.
        '''
        return self._gmdReadSymbol(gmd, symName, True, encoding)
    
    
    def _gmdFillSymbol(self, gmd, symbolPtr, arr, raw, merge, relaxedType):
        if isinstance(gmd, GamsDatabase):
            gmdH = gmd._gmd
        else:
            gmdH = gmd
        if isinstance(symbolPtr, _GamsSymbol):
            symPtr = symbolPtr._sym_ptr
        else:
            symPtr = symbolPtr

        symType = gmdSymbolType(gmdH, symPtr)[1]
        symDim = gmdSymbolDim(gmdH, symPtr)[1]

        self._validateArray(arr, symDim, symType)
        if relaxedType:
            arr = self._convertTypes(arr, symType, symDim, raw)
        return _gams2numpy.gmdFillSymbol(gmdHandleToPtr(gmdH), symPtr, arr, raw, merge)
    
    def gmdFillSymbolStr(self, gmd, symbolPtr, arr, merge=False, relaxedType=False):
        '''
        @brief Fills an existing GMD symbol with the data from the provided numpy array.
        @param gmd GMD handle created with 'gmdcc.new_gmdHandle_tp' or an instance of GamsDatabase.
        @param symbolPtr GMD symbol pointer or an instance of GamsParamater, GamsSet, GamsVariable or GamsEquation.
        @param arr Two dimensional numpy array containing strings for keys.
        @param merge Allow to write to a symbol that already contains data. In case of duplicate records, the last record will overwrite all previous ones (default: False).
        @param relaxedType Automatically convert the columns of the numpy array into the required data types if possible (default: False).
        @return None
        '''
        return self._gmdFillSymbol(gmd, symbolPtr, arr, False, merge, relaxedType)
    
    
    def gmdFillSymbolRaw(self, gmd, symbolPtr, arr, relaxedType=False):
        '''
        @brief Fills an existing GMD symbol with the data from the provided numpy array.
        @param gmd GMD handle created with 'gmdcc.new_gmdHandle_tp' or an instance of GamsDatabase.
        @param symbolPtr GMD symbol pointer or an instance of GamsParamater, GamsSet, GamsVariable or GamsEquation.
        @param arr Two dimensional numpy array containing integers for keys.
        @param relaxedType Automatically convert the columns of the numpy array into the required data types if possible (default: False).
        @return None
        '''
        return self._gmdFillSymbol(gmd, symbolPtr, arr, True, False, relaxedType)
